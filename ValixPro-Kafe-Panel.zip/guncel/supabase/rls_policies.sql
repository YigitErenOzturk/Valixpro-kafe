-- Review table/column names before running.
create or replace function public.current_shop_id() returns uuid language sql stable security definer set search_path=public as $$
 select shop_id from public.staff where user_id=auth.uid() and active=true limit 1
$$;
create or replace function public.is_shop_admin() returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.staff where user_id=auth.uid() and active=true and role in ('owner','admin','manager'))
$$;
-- Enable RLS and create shop-scoped policies on every table containing shop_id.
-- Never trust shop_id or role values sent by the browser; derive them from auth.uid().
