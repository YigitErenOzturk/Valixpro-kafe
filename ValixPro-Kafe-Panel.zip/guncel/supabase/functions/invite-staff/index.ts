import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ code: "Error", data: null, meta: { message: "Method not allowed" } }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  try {
    const body = await req.json();
    const { name, email, role, password } = body;

    if (!name || !email || !role || !password) {
      return new Response(
        JSON.stringify({ code: "InvalidParameter", data: null, meta: { message: "Tüm alanlar zorunludur." } }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (password.length < 6) {
      return new Response(
        JSON.stringify({ code: "InvalidParameter", data: null, meta: { message: "Şifre en az 6 karakter olmalıdır." } }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const validRoles = ["admin", "manager", "mechanic", "receptionist"];
    if (!validRoles.includes(role)) {
      return new Response(
        JSON.stringify({ code: "InvalidParameter", data: null, meta: { message: "Geçersiz rol." } }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!serviceRoleKey) {
      return new Response(
        JSON.stringify({ code: "Error", data: null, meta: { message: "Sunucu yapılandırma hatası." } }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL") || "";
    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey);

    // Get the caller's auth user from the JWT
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace("Bearer ", "");

    if (!token || token === serviceRoleKey) {
      return new Response(
        JSON.stringify({ code: "Unauthorized", data: null, meta: { message: "Yetkisiz erişim." } }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create a user client with the caller's JWT to get their identity
    const callerClient = createClient(supabaseUrl, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    // Decode the JWT to get the user
    const { data: { user: callerUser }, error: jwtError } = await callerClient.auth.getUser(token);

    if (jwtError || !callerUser) {
      return new Response(
        JSON.stringify({ code: "Unauthorized", data: null, meta: { message: "Geçersiz oturum." } }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get the caller's staff record to find their shop
    const { data: callerStaff, error: staffErr } = await supabaseAdmin
      .from("staff")
      .select("id, shop_id, role")
      .eq("user_id", callerUser.id)
      .eq("active", true)
      .maybeSingle();

    if (staffErr || !callerStaff) {
      return new Response(
        JSON.stringify({ code: "Forbidden", data: null, meta: { message: "Bu işlem için yetkiniz yok. Sadece mağaza personeli personel ekleyebilir." } }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Only owner, admin, or manager can invite staff
    if (!["owner", "admin", "manager"].includes(callerStaff.role)) {
      return new Response(
        JSON.stringify({ code: "Forbidden", data: null, meta: { message: "Bu işlem için yetkiniz yok. Sadece yöneticiler personel ekleyebilir." } }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const cleanEmail = email.trim().toLowerCase();

    // Check if email already used in staff
    const { data: existingStaff } = await supabaseAdmin
      .from("staff")
      .select("id")
      .eq("email", cleanEmail)
      .maybeSingle();

    if (existingStaff) {
      return new Response(
        JSON.stringify({ code: "Conflict", data: null, meta: { message: "Bu e-posta adresi zaten kayıtlı." } }),
        { status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create auth user for the new staff member
    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email: cleanEmail,
      password: password,
      email_confirm: true,
      user_metadata: { name: name.trim(), invited_by: callerUser.id },
    });

    if (authError) {
      return new Response(
        JSON.stringify({
          code: "Error",
          data: null,
          meta: { message: authError.message.includes("already") ? "Bu e-posta zaten kullanımda." : `Kullanıcı oluşturulamadı: ${authError.message}` }
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const newUserId = authData.user.id;

    // Create staff record linked to the shop
    const { data: newStaff, error: insertErr } = await supabaseAdmin
      .from("staff")
      .insert({
        name: name.trim(),
        email: cleanEmail,
        role: role,
        active: true,
        shop_id: callerStaff.shop_id,
        user_id: newUserId,
      })
      .select("id, name, email, role, shop_id, user_id, active, created_at")
      .single();

    if (insertErr) {
      // Rollback: delete the auth user
      await supabaseAdmin.auth.admin.deleteUser(newUserId);
      return new Response(
        JSON.stringify({ code: "Error", data: null, meta: { message: "Personel kaydı oluşturulamadı." } }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({
        code: "OK",
        data: newStaff,
        meta: { message: `${name.trim()} başarıyla ekibe davet edildi!` },
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Beklenmeyen bir hata oluştu.";
    return new Response(
      JSON.stringify({ code: "Error", data: null, meta: { message } }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
