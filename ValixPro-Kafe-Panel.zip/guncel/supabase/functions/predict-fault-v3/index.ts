const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const key = Deno.env.get("OPENAI_API_KEY");
    if (!key) {
      return new Response(
        JSON.stringify({ error: "OpenAI API anahtari bulunamadi. Lutfen OPENAI_API_KEY secret'i Supabase'de tanimlayin." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Mask key for debugging
    const keyPreview = key.substring(0, 7) + "..." + key.substring(key.length - 4);
    console.log("Using key:", keyPreview);

    const body = await req.json();
    const { make, model, year, notes } = body;

    if (!notes || !notes.trim()) {
      return new Response(
        JSON.stringify({ error: "Notlar gerekli" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const vehicle = [make, model, year].filter(Boolean).join(" ");
    const systemMsg = "Deneyimli oto tamir ustasisin. SADECE JSON yanit ver, baska hicbirsey yazma.";
    const userMsg = [
      "Arac bilgileri ve musteri sikayetine gore ariza tahmini yap.",
      "Arac: " + (vehicle || "Belirtilmemis"),
      "Sikayet: " + notes.trim(),
      "",
      "SADECE su JSON formatta yanit ver:",
      '{"predictedFault":"...","possibleCauses":["...","...","..."],"estimatedCost":"...","urgency":"Dusuk / Orta / Yuksek / Acil","recommendedAction":"..."}',
    ].join("\n");

    const aiRes = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + key,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemMsg },
          { role: "user", content: userMsg },
        ],
        temperature: 0.3,
        max_tokens: 400,
      }),
    });

    if (!aiRes.ok) {
      let errorDetail = "";
      try {
        const errBody = await aiRes.text();
        errorDetail = errBody.substring(0, 500);
        console.error("OpenAI error:", aiRes.status, errorDetail);
      } catch {
        errorDetail = "yanit okunamadi";
      }
      return new Response(
        JSON.stringify({
          error: "AI servisine ulasilamadi",
          detail: "HTTP " + aiRes.status + ": " + errorDetail,
        }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const aiData = await aiRes.json();
    const raw = aiData.choices?.[0]?.message?.content;

    if (!raw) {
      return new Response(
        JSON.stringify({ error: "AI bos yanit verdi" }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let cleaned = raw.trim();
    cleaned = cleaned.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");

    let prediction;
    try {
      prediction = JSON.parse(cleaned);
    } catch (_) {
      return new Response(
        JSON.stringify({ error: "AI yaniti islenemedi", raw: cleaned.substring(0, 200) }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ prediction }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return new Response(
      JSON.stringify({ error: "Sunucu hatasi: " + msg.substring(0, 300) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
