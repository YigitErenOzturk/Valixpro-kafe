
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { Resend } from "npm:resend@4.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ success: false, error: "Method not allowed" }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  const apiKey = Deno.env.get("RESEND_API_KEY");
  const fromDomain = Deno.env.get("RESEND_FROM_DOMAIN");

  if (!apiKey || !fromDomain) {
    return new Response(
      JSON.stringify({
        success: false,
        error: "Resend yapilandirmasi eksik. Lutfen Resend API key ve domain ayarlarini yapin.",
        missingConfig: true,
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  const resend = new Resend(apiKey);

  let bodyText = "";
  try {
    bodyText = await req.text();
  } catch (_e) {
    return new Response(
      JSON.stringify({ success: false, error: "Istek govdesi okunamadi" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  let to: string;
  let subject: string;
  let html: string;
  let customerName: string;

  try {
    const parsed = JSON.parse(bodyText);
    to = parsed.to;
    subject = parsed.subject;
    html = parsed.html;
    customerName = parsed.customerName || "";
  } catch (_e) {
    return new Response(
      JSON.stringify({ success: false, error: "Gecersiz JSON formati" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  if (!to || !subject || !html) {
    return new Response(
      JSON.stringify({ success: false, error: "to, subject ve html alanlari zorunludur" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  try {
    const { error: sendErr } = await resend.emails.send({
      from: "ValixPro <noreply@" + fromDomain + ">",
      to: to,
      subject: subject,
      html: html,
    });

    if (sendErr) {
      return new Response(
        JSON.stringify({
          success: false,
          error: sendErr.message || "E-posta gonderilemedi",
        }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({
        success: true,
        to: to,
        customerName: customerName,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Bilinmeyen hata";
    return new Response(
      JSON.stringify({ success: false, error: msg }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
