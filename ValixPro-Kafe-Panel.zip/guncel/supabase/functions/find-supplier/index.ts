const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const key = Deno.env.get("OPENAI_API_KEY");
    if (!key) {
      return new Response(
        JSON.stringify({ error: "OpenAI API anahtari bulunamadi. Lutfen OPENAI_API_KEY secret'i Supabase'de tanimlayin." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const body = await req.json();
    const { partName, partNumber, category, brand, vehicleInfo, quantity } = body;

    if (!partName || !partName.trim()) {
      return new Response(
        JSON.stringify({ error: "Parca adi gerekli" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const contextParts: string[] = [];
    if (partNumber) contextParts.push("Parca Kodu: " + partNumber);
    if (category) contextParts.push("Kategori: " + category);
    if (brand) contextParts.push("Marka: " + brand);
    if (vehicleInfo) contextParts.push("Arac: " + vehicleInfo);
    if (quantity) contextParts.push("Ihtiyac Adedi: " + quantity);

    const systemMsg = "Sen deneyimli bir oto yedek parca tedarik uzmanisin. Turkiye'deki otomotiv yedek parca piyasasini iyi biliyorsun. SADECE JSON yanit ver, baska hicbirsey yazma. Fiyatlar TL cinsinden olmali.";
    
    const userMsg = [
      "Asagidaki parca icin en uygun tedarikci onerilerini ve fiyat araliklarini ver:",
      "Parca Adi: " + partName.trim(),
      ...contextParts,
      "",
      "Su alanlarda detayli bilgi ver:",
      "- Bu parcayi nerelerden bulabilirim (online/fiziksel tedarikciler)",
      "- Tahmini fiyat araligi (TL)",
      "- Alternatif/muadil parca onerileri",
      "- Tahmini teslimat suresi",
      "- Hangi tip tedarikciler daha uygun (yetkili servis/yan sanayi/cikma/ithalatci)",
      "",
      "SADECE su JSON formatta yanit ver, baska bir sey yazma:",
      '{"partAnalysis":{"marketOverview":"...","priceRange":{"min":sayi,"max":sayi,"currency":"TL"},"recommendedSuppliers":[{"type":"...","name":"...","priceEstimate":"...","pros":"...","cons":"..."}],"alternativeParts":[{"name":"...","brand":"...","priceEstimate":"...","note":"..."}],"estimatedLeadTime":"...","buyingTips":"...","bestOption":"..."}}',
    ].join("\n");

    const aiRes = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + key,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemMsg },
          { role: "user", content: userMsg },
        ],
        temperature: 0.4,
        max_tokens: 800,
      }),
    });

    if (!aiRes.ok) {
      let errorDetail = "";
      try {
        const errBody = await aiRes.text();
        errorDetail = errBody.substring(0, 500);
        console.error("OpenAI error:", aiRes.status, errorDetail);
      } catch {
        errorDetail = "yanit okunamadi";
      }
      return new Response(
        JSON.stringify({
          error: "AI servisine ulasilamadi",
          detail: "HTTP " + aiRes.status + ": " + errorDetail,
        }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const aiData = await aiRes.json();
    const raw = aiData.choices?.[0]?.message?.content;

    if (!raw) {
      return new Response(
        JSON.stringify({ error: "AI bos yanit verdi" }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let cleaned = raw.trim();
    cleaned = cleaned.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");

    let prediction;
    try {
      prediction = JSON.parse(cleaned);
    } catch (_) {
      return new Response(
        JSON.stringify({ error: "AI yaniti islenemedi", raw: cleaned.substring(0, 300) }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ result: prediction }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return new Response(
      JSON.stringify({ error: "Sunucu hatasi: " + msg.substring(0, 300) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
