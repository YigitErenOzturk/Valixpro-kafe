
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ code: "Error", data: null, meta: { message: "Method not allowed" } }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  try {
    const body = await req.json();
    const { shopName, staffName } = body;

    // Extract the authenticated user's JWT from the Authorization header
    const authHeader = req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return new Response(
        JSON.stringify({ code: "Unauthorized", data: null, meta: { message: "Oturum gerekli." } }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const token = authHeader.replace("Bearer ", "");

    if (!shopName || !staffName) {
      return new Response(
        JSON.stringify({ code: "InvalidParameter", data: null, meta: { message: "Tüm alanlar zorunludur." } }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!serviceRoleKey) {
      return new Response(
        JSON.stringify({ code: "Error", data: null, meta: { message: "Sunucu yapılandırma hatası." } }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL") || "";
    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey);

    // Verify the JWT and get user info
    const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(token);

    if (userError || !user) {
      return new Response(
        JSON.stringify({ code: "Unauthorized", data: null, meta: { message: "Geçersiz oturum." } }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const userId = user.id;
    const userEmail = user.email || "";

    // 1. Check if shop name already exists
    const { data: existingShop, error: shopCheckError } = await supabaseAdmin
      .from("shops")
      .select("id")
      .eq("name", shopName.trim())
      .maybeSingle();

    if (shopCheckError) {
      return new Response(
        JSON.stringify({ code: "Error", data: null, meta: { message: "Mağaza kontrolü sırasında hata oluştu." } }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (existingShop) {
      return new Response(
        JSON.stringify({ code: "Conflict", data: null, meta: { message: `${shopName} adında bir mağaza zaten mevcut.` } }),
        { status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 2. Check if user already has a shop/staff record
    const { data: existingStaff } = await supabaseAdmin
      .from("staff")
      .select("id")
      .eq("user_id", userId)
      .maybeSingle();

    if (existingStaff) {
      return new Response(
        JSON.stringify({ code: "Conflict", data: null, meta: { message: "Bu hesap zaten bir mağazaya kayıtlı." } }),
        { status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 3. Create shop record
    const { data: shopData, error: shopError } = await supabaseAdmin
      .from("shops")
      .insert({
        name: shopName.trim(),
        owner_id: userId,
      })
      .select("id")
      .single();

    if (shopError) {
      return new Response(
        JSON.stringify({ code: "Error", data: null, meta: { message: "Mağaza oluşturulamadı." } }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 4. Create staff record (owner role)
    const { data: staffData, error: staffError } = await supabaseAdmin
      .from("staff")
      .insert({
        name: staffName.trim(),
        email: userEmail,
        role: "owner",
        active: true,
        shop_id: shopData.id,
        user_id: userId,
      })
      .select("id, name, email, role, shop_id, user_id")
      .single();

    if (staffError) {
      // Rollback: delete shop
      await supabaseAdmin.from("shops").delete().eq("id", shopData.id);
      return new Response(
        JSON.stringify({ code: "Error", data: null, meta: { message: "Personel kaydı oluşturulamadı." } }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({
        code: "OK",
        data: {
          shop: { id: shopData.id, name: shopName.trim() },
          staff: staffData,
          user_id: userId,
        },
        meta: { message: "Kayıt başarılı!" },
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Beklenmeyen bir hata oluştu.";
    return new Response(
      JSON.stringify({ code: "Error", data: null, meta: { message } }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
