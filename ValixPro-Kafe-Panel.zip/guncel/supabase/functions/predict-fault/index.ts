const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    if (!OPENAI_API_KEY) {
      return new Response(
        JSON.stringify({ error: "OPENAI_API_KEY bulunamadi" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const body = await req.json();
    const { make, model, year, notes } = body;

    if (!notes || !notes.trim()) {
      return new Response(
        JSON.stringify({ error: "Notlar gerekli" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const vehicleInfo = [make, model, year].filter(Boolean).join(" ");
    const prompt = [
      "Sen deneyimli bir oto tamir ustasisin.",
      "Arac: " + (vehicleInfo || "Belirtilmemis"),
      "Problem: " + notes.trim(),
      "",
      "Yanit olarak SADECE su JSON formatinda dön (baska hicbir sey yazma):",
      '{',
      '  "predictedFault": "...",',
      '  "possibleCauses": ["...","...","..."],',
      '  "estimatedCost": "...",',
      '  "urgency": "Dusuk / Orta / Yuksek / Acil",',
      '  "recommendedAction": "..."',
      '}',
    ].join("\n");

    const openAiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + OPENAI_API_KEY,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "Sen deneyimli bir oto tamir ustasisin. SADECE JSON yanit ver, baska hicbir sey yazma." },
          { role: "user", content: prompt },
        ],
        temperature: 0.3,
        max_tokens: 400,
      }),
    });

    if (!openAiResponse.ok) {
      const errText = await openAiResponse.text();
      return new Response(
        JSON.stringify({ error: "AI servisi yanit vermedi (status " + openAiResponse.status + "). Lutfen tekrar deneyin." }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const aiData = await openAiResponse.json();
    const rawContent = aiData.choices?.[0]?.message?.content;

    if (!rawContent) {
      return new Response(
        JSON.stringify({ error: "AI bos yanit verdi." }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let cleaned = rawContent.trim();
    cleaned = cleaned.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");

    let prediction;
    try {
      prediction = JSON.parse(cleaned);
    } catch (_e) {
      return new Response(
        JSON.stringify({ error: "AI yaniti islenemedi." }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ prediction }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: "Sunucu hatasi: " + (err instanceof Error ? err.message : String(err)).substring(0, 200) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
