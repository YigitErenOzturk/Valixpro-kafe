
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "npm:resend@4.0.0";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY") || "";
const RESEND_FROM_DOMAIN = Deno.env.get("RESEND_FROM_DOMAIN") || "";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") || "";
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";

const resend = new Resend(RESEND_API_KEY);
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

serve(async (req: Request) => {
  try {
    const today = new Date().toISOString().split("T")[0];

    const { data: reminders, error: remErr } = await supabase
      .from("maintenance_reminders")
      .select("id, vehicle_id, service_type, description, service_date, reminder_interval_months, next_reminder_date, shop_id")
      .eq("status", "active")
      .lte("next_reminder_date", today);

    if (remErr) throw remErr;
    if (!reminders || reminders.length === 0) {
      return new Response(JSON.stringify({ sent: 0, message: "No overdue reminders" }), {
        headers: { "Content-Type": "application/json" },
        status: 200,
      });
    }

    const vehicleIds = [...new Set(reminders.map((r: any) => r.vehicle_id))];

    const { data: vehicles } = await supabase
      .from("vehicles")
      .select("id, make, model, year, plate_number, customer_id")
      .in("id", vehicleIds);

    const vehicleMap: Record<string, any> = {};
    if (vehicles) {
      vehicles.forEach((v: any) => { vehicleMap[v.id] = v; });
    }

    const customerIds = [...new Set(
      (vehicles || []).map((v: any) => v.customer_id).filter(Boolean)
    )];

    const { data: customers } = await supabase
      .from("customers")
      .select("id, name, email, phone")
      .in("id", customerIds);

    const customerMap: Record<string, any> = {};
    if (customers) {
      customers.forEach((c: any) => { customerMap[c.id] = c; });
    }

    const shopIds = [...new Set(reminders.map((r: any) => r.shop_id).filter(Boolean))];
    const { data: shopSettings } = await supabase
      .from("shop_settings")
      .select("shop_id, notification_prefs")
      .in("shop_id", shopIds);

    const shopPrefsMap: Record<string, any> = {};
    if (shopSettings) {
      shopSettings.forEach((s: any) => {
        shopPrefsMap[s.shop_id] = s.notification_prefs || {};
      });
    }

    let emailSent = 0;
    const errors: string[] = [];

    for (const reminder of reminders) {
      const vehicle = vehicleMap[reminder.vehicle_id];
      if (!vehicle) continue;

      const customer = vehicle.customer_id ? customerMap[vehicle.customer_id] : null;
      const prefs = shopPrefsMap[reminder.shop_id] || {};

      const vehicleName = [vehicle.year, vehicle.make, vehicle.model].filter(Boolean).join(" ");
      const plateLabel = vehicle.plate_number ? " (" + vehicle.plate_number + ")" : "";

      const serviceDateFormatted = new Date(reminder.service_date).toLocaleDateString("tr-TR", {
        year: "numeric", month: "long", day: "numeric",
      });

      // Email notification via Resend
      if (prefs.emailNotifications !== false && customer?.email && RESEND_API_KEY) {
        const html = [
          '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">',
          '<div style="background: #f8f8f8; border-radius: 12px; padding: 30px; border: 1px solid #e5e5e5;">',
          '<h2 style="color: #333; margin-top: 0;">Bakim Hatirlatmasi</h2>',
          '<p style="color: #666; font-size: 16px;">Merhaba ' + (customer?.name || "Musterimiz") + ',</p>',
          '<p style="color: #666; font-size: 16px;">',
          '<strong>' + vehicleName + plateLabel + '</strong> araciniz icin planlanan bakim zamani geldi.',
          '</p>',
          '<div style="background: #fff; border-radius: 8px; padding: 20px; margin: 20px 0; border: 1px solid #e5e5e5;">',
          '<p style="margin: 0 0 8px 0; color: #444;"><strong>Servis:</strong> ' + reminder.service_type + '</p>',
          reminder.description ? '<p style="margin: 0 0 8px 0; color: #666; font-size: 14px;">' + reminder.description + '</p>' : '',
          '<p style="margin: 0 0 4px 0; color: #888; font-size: 14px;">Yapilis Tarihi: ' + serviceDateFormatted + '</p>',
          '</div>',
          '<p style="color: #666; font-size: 16px;">Bakim randevusu almak icin lutfen bizimle iletisime gecin.</p>',
          '<div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e5e5;">',
          '<p style="color: #999; font-size: 12px; margin: 0;">Bu otomatik bir hatirlatmadir. ValixPro Bakim Takip Sistemi tarafindan gonderilmistir.</p>',
          '</div>',
          '</div>',
          '</div>',
        ].join("\n");

        try {
          const { error: sendErr } = await resend.emails.send({
            from: "ValixPro <noreply@" + RESEND_FROM_DOMAIN + ">",
            to: customer.email,
            subject: "Bakim Hatirlatmasi: " + reminder.service_type + " - " + vehicleName,
            html: html,
          });

          if (sendErr) {
            errors.push("Email to " + customer.email + ": " + sendErr.message);
          } else {
            emailSent++;
          }
        } catch (e: any) {
          errors.push("Email to " + customer.email + ": " + e.message);
        }
      }

      // Mark as notified if email sent
      if (emailSent > 0) {
        await supabase
          .from("maintenance_reminders")
          .update({ status: "notified", notified_at: new Date().toISOString() })
          .eq("id", reminder.id);
      }
    }

    return new Response(
      JSON.stringify({
        emailSent,
        total: reminders.length,
        errors: errors.length > 0 ? errors.slice(0, 10) : undefined,
        message: "Email: " + emailSent + " of " + reminders.length,
      }),
      { headers: { "Content-Type": "application/json" }, status: 200 }
    );
  } catch (err: any) {
    console.error("send-maintenance-reminders error:", err);
    return new Response(
      JSON.stringify({ error: err.message }),
      { headers: { "Content-Type": "application/json" }, status: 500 }
    );
  }
});
