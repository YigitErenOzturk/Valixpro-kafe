const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  const hasKey = !!Deno.env.get("OPENAI_API_KEY");

  return new Response(
    JSON.stringify({ ok: true, hasOpenAiKey: hasKey }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
});
