export type CafeOrderStatus = 'Yeni' | 'Hazırlanıyor' | 'Hazır' | 'Teslim Edildi';

export interface CafeMenuItem {
  id: string;
  name: string;
  category: string;
  price: number;
  icon: string;
}

export interface CafeOrderItem extends CafeMenuItem { qty: number; }

export interface CafeOrder {
  id: string;
  number: number;
  table: string;
  type: 'Masa' | 'Paket' | 'Gel-Al';
  items: CafeOrderItem[];
  total: number;
  status: CafeOrderStatus;
  createdAt: string;
}

export const menuItems: CafeMenuItem[] = [
  { id:'m1', name:'Espresso', category:'Kahve', price:75, icon:'☕' },
  { id:'m2', name:'Americano', category:'Kahve', price:90, icon:'☕' },
  { id:'m3', name:'Cappuccino', category:'Kahve', price:110, icon:'🥛' },
  { id:'m4', name:'Latte', category:'Kahve', price:115, icon:'🥛' },
  { id:'m5', name:'Cold Brew', category:'Soğuk İçecek', price:125, icon:'🧊' },
  { id:'m6', name:'Limonata', category:'Soğuk İçecek', price:95, icon:'🍋' },
  { id:'m7', name:'San Sebastian', category:'Tatlı', price:165, icon:'🍰' },
  { id:'m8', name:'Kruvasan', category:'Yiyecek', price:105, icon:'🥐' },
  { id:'m9', name:'Tavuklu Sandviç', category:'Yiyecek', price:185, icon:'🥪' },
  { id:'m10', name:'Cookie', category:'Tatlı', price:70, icon:'🍪' },
];

const KEY='valix_cafe_orders';
export const loadOrders=():CafeOrder[]=>{
  try { return JSON.parse(localStorage.getItem(KEY)||'[]'); } catch { return []; }
};
export const saveOrders=(orders:CafeOrder[])=>localStorage.setItem(KEY,JSON.stringify(orders));
export const addOrder=(order:CafeOrder)=>{ const all=loadOrders(); saveOrders([order,...all]); };
export const updateOrderStatus=(id:string,status:CafeOrderStatus)=>{
  saveOrders(loadOrders().map(o=>o.id===id?{...o,status}:o));
};
