type RequiredEnvKey =
  | 'VITE_PUBLIC_SUPABASE_URL'
  | 'VITE_PUBLIC_SUPABASE_ANON_KEY';

function readEnv(key: RequiredEnvKey): string {
  const value = import.meta.env[key]?.trim();
  if (!value) {
    throw new Error(`Missing required environment variable: ${key}`);
  }
  return value;
}

export const env = {
  supabaseUrl: readEnv('VITE_PUBLIC_SUPABASE_URL'),
  supabaseAnonKey: readEnv('VITE_PUBLIC_SUPABASE_ANON_KEY'),
  emailJsPublicKey: import.meta.env.VITE_PUBLIC_EMAILJS_PUBLIC_KEY?.trim() ?? '',
  emailJsServiceId: import.meta.env.VITE_PUBLIC_EMAILJS_SERVICE_ID?.trim() ?? '',
  emailJsTemplateId: import.meta.env.VITE_PUBLIC_EMAILJS_TEMPLATE_ID?.trim() ?? '',
} as const;
