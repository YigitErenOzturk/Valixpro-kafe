export const STAFF_STORAGE_KEY = 'autofix_staff';

export type StoredStaff = {
  id: string;
  name: string;
  email: string;
  role: string;
  avatar_url?: string | null;
  shop_id: string;
  shop_name?: string;
};

export function getStoredStaff(): StoredStaff | null {
  try {
    const raw = localStorage.getItem(STAFF_STORAGE_KEY);
    if (!raw) return null;
    const value = JSON.parse(raw) as Partial<StoredStaff>;
    if (!value.id || !value.shop_id || !value.email || !value.role) {
      clearStoredStaff();
      return null;
    }
    return value as StoredStaff;
  } catch {
    clearStoredStaff();
    return null;
  }
}

export function setStoredStaff(staff: StoredStaff): void {
  localStorage.setItem(STAFF_STORAGE_KEY, JSON.stringify(staff));
}

export function clearStoredStaff(): void {
  localStorage.removeItem(STAFF_STORAGE_KEY);
}
