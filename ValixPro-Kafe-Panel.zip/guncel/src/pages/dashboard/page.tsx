import { Link } from 'react-router-dom';
import { useEffect, useMemo, useState } from 'react';
import { loadOrders, type CafeOrder } from '@/lib/cafe';

export default function Dashboard(){
 const [orders,setOrders]=useState<CafeOrder[]>([]);
 useEffect(()=>{setOrders(loadOrders())},[]);
 const today=new Date().toDateString();
 const todays=useMemo(()=>orders.filter(o=>new Date(o.createdAt).toDateString()===today),[orders]);
 const revenue=todays.reduce((s,o)=>s+o.total,0);
 const active=todays.filter(o=>o.status!=='Teslim Edildi').length;
 const avg=todays.length?revenue/todays.length:0;
 const recent=todays.slice(0,6);
 return <div className="space-y-6">
  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
   <div><p className="text-xs font-semibold text-primary-600 uppercase tracking-[.2em]">ValixPro Kafe</p><h2 className="text-2xl font-heading font-bold text-foreground-950 mt-1">Kafe yönetim merkezi</h2><p className="text-sm text-foreground-500 mt-1">Sipariş, kasa, mutfak ve stok akışınızı tek ekrandan yönetin.</p></div>
   <div className="flex gap-2"><Link to="/pos" className="px-4 py-2.5 rounded-lg bg-primary-500 hover:bg-primary-600 text-background-50 text-sm font-semibold"><i className="ri-add-line mr-2"/>Yeni Sipariş</Link><Link to="/kitchen" className="px-4 py-2.5 rounded-lg bg-background-50 border border-background-200 text-sm font-semibold text-foreground-700"><i className="ri-restaurant-2-line mr-2"/>Mutfağı Aç</Link></div>
  </div>
  <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4">
   {[[`${todays.length}`,'Bugünkü Sipariş','ri-receipt-line'],[`${active}`,'Aktif Sipariş','ri-time-line'],[`₺${revenue.toLocaleString('tr-TR')}`,'Bugünkü Ciro','ri-wallet-3-line'],[`₺${Math.round(avg).toLocaleString('tr-TR')}`,'Ortalama Sepet','ri-bar-chart-box-line']].map(([v,l,i])=><div key={l} className="bg-background-50/90 border border-background-200/70 rounded-xl p-5"><div className="flex justify-between"><div><p className="text-xs text-foreground-500 font-medium">{l}</p><p className="text-2xl font-bold text-foreground-950 mt-1">{v}</p></div><div className="w-10 h-10 rounded-xl bg-primary-100 flex items-center justify-center text-primary-600"><i className={`${i} text-lg`}/></div></div></div>)}
  </div>
  <div className="grid xl:grid-cols-3 gap-6">
   <div className="xl:col-span-2 bg-background-50/90 border border-background-200/70 rounded-xl overflow-hidden"><div className="px-5 py-4 border-b border-background-200 flex justify-between"><div><h3 className="font-semibold text-foreground-950">Son Siparişler</h3><p className="text-xs text-foreground-500">Bugünkü sipariş akışı</p></div><Link to="/orders" className="text-xs font-semibold text-primary-600">Tümünü gör</Link></div><div className="divide-y divide-background-200">{recent.length?recent.map(o=><div key={o.id} className="p-4 flex items-center justify-between gap-4"><div><p className="font-semibold text-sm text-foreground-900">#{o.number} · {o.table}</p><p className="text-xs text-foreground-500 mt-1">{o.items.map(x=>`${x.qty}× ${x.name}`).join(', ')}</p></div><div className="text-right"><p className="font-bold text-foreground-950">₺{o.total}</p><span className="text-xs text-primary-600">{o.status}</span></div></div>):<div className="p-10 text-center text-sm text-foreground-500">Henüz sipariş yok. POS ekranından ilk siparişi oluşturun.</div>}</div></div>
   <div className="bg-background-50/90 border border-background-200/70 rounded-xl p-5"><h3 className="font-semibold text-foreground-950">Hızlı İşlemler</h3><div className="grid gap-3 mt-4">{[['/pos','ri-shopping-bag-3-line','POS Satış Ekranı'],['/kitchen','ri-restaurant-2-line','Mutfak Ekranı'],['/menu','ri-qr-code-line','QR Menü'],['/inventory','ri-archive-stack-line','Stok Takibi']].map(([to,ic,tx])=><Link key={to} to={to} className="flex items-center gap-3 p-3 rounded-xl border border-background-200 hover:border-primary-300 hover:bg-primary-50/40 transition"><span className="w-9 h-9 rounded-lg bg-primary-100 flex items-center justify-center text-primary-600"><i className={ic}/></span><span className="text-sm font-medium text-foreground-800">{tx}</span><i className="ri-arrow-right-s-line ml-auto text-foreground-400"/></Link>)}</div></div>
  </div>
 </div>
}