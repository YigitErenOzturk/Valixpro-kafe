import { useState, useMemo } from 'react';
import Pagination from '@/components/base/Pagination';

interface Staff {
  id: string;
  name: string;
  email: string | null;
  role: string;
  phone: string | null;
  active: boolean;
  created_at: string;
}

interface StaffListProps {
  staff: Staff[];
  onView: (staff: Staff) => void;
  onEdit: (staff: Staff) => void;
  onDelete: (id: string) => void;
  loading: boolean;
}

const ROLE_LABELS: Record<string, string> = {
  admin: 'Yönetici',
  manager: 'Müdür',
  mechanic: 'Teknisyen',
  receptionist: 'Resepsiyonist',
};

const ROLE_COLORS: Record<string, string> = {
  admin: 'bg-accent-100 text-accent-800',
  manager: 'bg-primary-100 text-primary-700',
  mechanic: 'bg-secondary-100 text-secondary-800',
  receptionist: 'bg-background-200 text-foreground-700',
};

const ROLE_ICONS: Record<string, string> = {
  admin: 'ri-shield-star-line',
  manager: 'ri-briefcase-line',
  mechanic: 'ri-tools-line',
  receptionist: 'ri-customer-service-2-line',
};

export default function StaffList({ staff, onView, onEdit, onDelete, loading }: StaffListProps) {
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'role' | 'date'>('name');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const filtered = useMemo(() => {
    let rows = [...staff];

    if (search.trim()) {
      const q = search.toLowerCase();
      rows = rows.filter(
        (s) =>
          s.name.toLowerCase().includes(q) ||
          (s.email && s.email.toLowerCase().includes(q)) ||
          (s.phone && s.phone.toLowerCase().includes(q)) ||
          (ROLE_LABELS[s.role] || s.role).toLowerCase().includes(q),
      );
    }

    rows.sort((a, b) => {
      let cmp = 0;
      if (sortBy === 'name') cmp = a.name.localeCompare(b.name);
      else if (sortBy === 'role') cmp = (a.role || '').localeCompare(b.role || '');
      else if (sortBy === 'date') cmp = new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
      return sortDir === 'asc' ? cmp : -cmp;
    });

    return rows;
  }, [staff, search, sortBy, sortDir]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const paginated = filtered.slice((safePage - 1) * pageSize, safePage * pageSize);

  const handleSort = (field: 'name' | 'role' | 'date') => {
    if (sortBy === field) {
      setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortBy(field);
      setSortDir('asc');
    }
    setPage(1);
  };

  const handleSearch = (val: string) => {
    setSearch(val);
    setPage(1);
  };

  const handlePageSizeChange = (size: number) => {
    setPageSize(size);
    setPage(1);
  };

  const sortIcon = (field: string) => {
    if (sortBy !== field) return 'ri-arrow-up-down-line';
    return sortDir === 'asc' ? 'ri-arrow-up-line' : 'ri-arrow-down-line';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center gap-3">
          <i className="ri-loader-4-line animate-spin text-3xl text-primary-500"></i>
          <p className="text-sm text-foreground-500">Personel yükleniyor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-background-50 border border-background-200/70 rounded-xl">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 px-5 py-4 border-b border-background-200/70">
        <div className="relative w-full sm:w-72">
          <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-foreground-400 text-sm"></i>
          <input
            type="text"
            value={search}
            onChange={(e) => handleSearch(e.target.value)}
            placeholder="İsim, rol veya iletişim bilgisi ara..."
            className="w-full pl-9 pr-3 py-2 text-sm bg-background-100 border border-background-200/70 rounded-lg text-foreground-900 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-300 focus:border-primary-300"
          />
        </div>
        <span className="text-xs text-foreground-500 whitespace-nowrap">
          Gösterilen <span className="font-semibold text-foreground-900">{paginated.length}</span> / {filtered.length} personel
        </span>
      </div>

      <div className="hidden xl:block overflow-x-auto">
        {filtered.length === 0 ? (
          <div className="px-5 py-12 text-center text-sm text-foreground-500">
            Personel bulunamadı.
          </div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="border-b border-background-200/70">
                <th
                  className="text-left px-5 py-3 text-xs font-medium text-foreground-500 cursor-pointer hover:text-foreground-700 select-none whitespace-nowrap"
                  onClick={() => handleSort('name')}
                >
                  <span className="flex items-center gap-1">
                    Personel <i className={sortIcon('name') + ' text-[10px]'}></i>
                  </span>
                </th>
                <th className="text-left px-5 py-3 text-xs font-medium text-foreground-500 whitespace-nowrap">İletişim</th>
                <th
                  className="text-left px-5 py-3 text-xs font-medium text-foreground-500 cursor-pointer hover:text-foreground-700 select-none whitespace-nowrap"
                  onClick={() => handleSort('role')}
                >
                  <span className="flex items-center gap-1">
                    Rol <i className={sortIcon('role') + ' text-[10px]'}></i>
                  </span>
                </th>
                <th className="text-left px-5 py-3 text-xs font-medium text-foreground-500 whitespace-nowrap">Durum</th>
                <th
                  className="text-left px-5 py-3 text-xs font-medium text-foreground-500 cursor-pointer hover:text-foreground-700 select-none whitespace-nowrap"
                  onClick={() => handleSort('date')}
                >
                  <span className="flex items-center gap-1">
                    Katılım <i className={sortIcon('date') + ' text-[10px]'}></i>
                  </span>
                </th>
                <th className="text-left px-5 py-3 text-xs font-medium text-foreground-500 whitespace-nowrap">İşlem</th>
              </tr>
            </thead>
            <tbody>
              {paginated.map((member) => (
                <tr
                  key={member.id}
                  className="border-b border-background-100/70 hover:bg-background-100/40 transition-colors"
                >
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-full bg-primary-100 flex items-center justify-center flex-shrink-0">
                        <span className="text-xs font-bold text-primary-600">
                          {member.name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase()}
                        </span>
                      </div>
                      <p className="text-sm text-foreground-900 font-medium whitespace-nowrap">{member.name}</p>
                    </div>
                  </td>
                  <td className="px-5 py-3">
                    <div className="space-y-0.5">
                      {member.email && (
                        <p className="text-sm text-foreground-600 whitespace-nowrap flex items-center gap-1.5">
                          <i className="ri-mail-line text-xs text-foreground-400"></i>
                          {member.email}
                        </p>
                      )}
                      {member.phone && (
                        <p className="text-sm text-foreground-600 whitespace-nowrap flex items-center gap-1.5">
                          <i className="ri-phone-line text-xs text-foreground-400"></i>
                          {member.phone}
                        </p>
                      )}
                      {!member.email && !member.phone && (
                        <p className="text-sm text-foreground-400 whitespace-nowrap">—</p>
                      )}
                    </div>
                  </td>
                  <td className="px-5 py-3 whitespace-nowrap">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${ROLE_COLORS[member.role] || 'bg-background-200 text-foreground-700'}`}>
                      <i className={(ROLE_ICONS[member.role] || 'ri-user-line') + ' text-[10px]'}></i>
                      {ROLE_LABELS[member.role] || member.role}
                    </span>
                  </td>
                  <td className="px-5 py-3 whitespace-nowrap">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${
                      member.active
                        ? 'bg-secondary-100 text-secondary-800'
                        : 'bg-background-200 text-foreground-500'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${member.active ? 'bg-secondary-500' : 'bg-foreground-400'}`}></span>
                      {member.active ? 'Aktif' : 'Pasif'}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-sm text-foreground-600 whitespace-nowrap">
                    {new Date(member.created_at).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' })}
                  </td>
                  <td className="px-5 py-3 whitespace-nowrap">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => onView(member)}
                        className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-background-200 text-foreground-500 hover:text-foreground-700 transition-colors cursor-pointer"
                        title="Görüntüle"
                      >
                        <i className="ri-eye-line text-sm"></i>
                      </button>
                      <button
                        onClick={() => onEdit(member)}
                        className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-background-200 text-foreground-500 hover:text-foreground-700 transition-colors cursor-pointer"
                        title="Düzenle"
                      >
                        <i className="ri-edit-line text-sm"></i>
                      </button>
                      <button
                        onClick={() => onDelete(member.id)}
                        className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-accent-50 text-foreground-500 hover:text-accent-600 transition-colors cursor-pointer"
                        title="Sil"
                      >
                        <i className="ri-delete-bin-line text-sm"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Mobile/Tablet cards */}
      <div className="xl:hidden">
        {filtered.length === 0 ? (
          <div className="px-5 py-12 text-center text-sm text-foreground-500">
            Personel bulunamadı.
          </div>
        ) : (
          <div className="space-y-3 p-4">
            {paginated.map((member) => (
              <div key={member.id} className="bg-background-50 border border-background-200/70 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 rounded-full bg-primary-100 flex items-center justify-center flex-shrink-0">
                    <span className="text-sm font-bold text-primary-600">
                      {member.name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase()}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-foreground-900">{member.name}</p>
                    <div className="mt-1 flex items-center gap-2 flex-wrap">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${ROLE_COLORS[member.role] || 'bg-background-200 text-foreground-700'}`}>
                        <i className={(ROLE_ICONS[member.role] || 'ri-user-line') + ' text-[10px]'}></i>
                        {ROLE_LABELS[member.role] || member.role}
                      </span>
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${member.active ? 'bg-secondary-100 text-secondary-800' : 'bg-background-200 text-foreground-500'}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${member.active ? 'bg-secondary-500' : 'bg-foreground-400'}`}></span>
                        {member.active ? 'Aktif' : 'Pasif'}
                      </span>
                    </div>
                    <div className="mt-1 space-y-0.5">
                      {member.email && (
                        <p className="text-xs text-foreground-600 flex items-center gap-1">
                          <i className="ri-mail-line text-xs text-foreground-400"></i>
                          {member.email}
                        </p>
                      )}
                      {member.phone && (
                        <p className="text-xs text-foreground-600 flex items-center gap-1">
                          <i className="ri-phone-line text-xs text-foreground-400"></i>
                          {member.phone}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
                <div className="mt-3 pt-3 border-t border-background-200/70 flex items-center justify-end gap-2">
                  <button onClick={() => onView(member)} className="w-11 h-11 flex items-center justify-center rounded-lg hover:bg-background-200 text-foreground-500 hover:text-foreground-700 transition-colors cursor-pointer">
                    <i className="ri-eye-line text-base"></i>
                  </button>
                  <button onClick={() => onEdit(member)} className="w-11 h-11 flex items-center justify-center rounded-lg hover:bg-background-200 text-foreground-500 hover:text-foreground-700 transition-colors cursor-pointer">
                    <i className="ri-edit-line text-base"></i>
                  </button>
                  <button onClick={() => onDelete(member.id)} className="w-11 h-11 flex items-center justify-center rounded-lg hover:bg-accent-50 text-foreground-500 hover:text-accent-600 transition-colors cursor-pointer">
                    <i className="ri-delete-bin-line text-base"></i>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <Pagination
        currentPage={safePage}
        totalPages={totalPages}
        pageSize={pageSize}
        totalItems={filtered.length}
        onPageChange={setPage}
        onPageSizeChange={handlePageSizeChange}
      />
    </div>
  );
}