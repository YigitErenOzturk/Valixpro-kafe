import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

interface StaffFormData {
  id: string;
  name: string;
  email: string | null;
  role: string;
  phone: string | null;
  active: boolean;
}

interface StaffFormProps {
  open: boolean;
  editData: StaffFormData | null;
  onClose: () => void;
  onSaved: (message?: string) => void;
}

const ROLES = [
  { value: 'admin', label: 'Yönetici', icon: 'ri-shield-star-line' },
  { value: 'manager', label: 'Müdür', icon: 'ri-briefcase-line' },
  { value: 'mechanic', label: 'Teknisyen', icon: 'ri-tools-line' },
  { value: 'receptionist', label: 'Resepsiyonist', icon: 'ri-customer-service-2-line' },
];

export default function StaffForm({ open, editData, onClose, onSaved }: StaffFormProps) {
  const isEdit = !!editData;
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState('mechanic');
  const [active, setActive] = useState(true);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    if (editData) {
      setName(editData.name || '');
      setEmail(editData.email || '');
      setPhone(editData.phone || '');
      setRole(editData.role || 'mechanic');
      setActive(editData.active);
      setPassword('');
    } else {
      setName('');
      setEmail('');
      setPhone('');
      setRole('mechanic');
      setActive(true);
      setPassword('');
    }
    setError('');
    setShowPassword(false);
  }, [editData, open]);

  const validate = useCallback((): string | null => {
    if (!name.trim()) return 'Personel adı zorunludur';
    if (!email || !email.trim()) return 'E-posta adresi zorunludur';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return 'Geçersiz e-posta adresi';
    if (!isEdit && !password.trim()) return 'Şifre zorunludur';
    if (!isEdit && password.length < 6) return 'Şifre en az 6 karakter olmalıdır';
    return null;
  }, [name, email, password, isEdit]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }

    try {
      setSaving(true);
      setError('');

      if (isEdit && editData) {
        // Edit existing staff — direct update
        const payload = {
          name: name.trim(),
          email: email.trim() || null,
          phone: phone.trim() || null,
          role,
          active,
        };

        const { error: uErr } = await supabase
          .from('staff')
          .update(payload)
          .eq('id', editData.id);

        if (uErr) throw uErr;
        onSaved('Personel bilgileri güncellendi.');
      } else {
        // New staff — invite via edge function
        // refreshSession ensures we have a fresh, non-expired token
        const { data: refreshData, error: refreshErr } = await supabase.auth.refreshSession();
        const token = refreshData.session?.access_token;

        if (refreshErr || !token) {
          // fallback to getSession if refresh fails (e.g. no refresh token in storage)
          const { data: sessionData } = await supabase.auth.getSession();
          const fallbackToken = sessionData.session?.access_token;

          if (!fallbackToken) {
            setError('Oturum bulunamadı veya süresi doldu. Lütfen tekrar giriş yapın.');
            setSaving(false);
            return;
          }

          // use fallback token but still strip trailing slash
          const baseUrl = import.meta.env.VITE_PUBLIC_SUPABASE_URL.replace(/\/+$/, '');
          const res = await fetch(`${baseUrl}/functions/v1/invite-staff`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${fallbackToken}`,
            },
            body: JSON.stringify({
              name: name.trim(),
              email: email.trim().toLowerCase(),
              role,
              password,
            }),
          });

          const result = await res.json();

          if (!res.ok || result.code !== 'OK') {
            setError(result.meta?.message || 'Davet gönderilemedi.');
            setSaving(false);
            return;
          }

          onSaved(result.meta?.message || `${name.trim()} başarıyla ekibe eklendi!`);
          return;
        }

        // strip trailing slash to avoid double-slash URL
        const baseUrl = import.meta.env.VITE_PUBLIC_SUPABASE_URL.replace(/\/+$/, '');
        const res = await fetch(`${baseUrl}/functions/v1/invite-staff`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            name: name.trim(),
            email: email.trim().toLowerCase(),
            role,
            password,
          }),
        });

        const result = await res.json();

        if (!res.ok || result.code !== 'OK') {
          setError(result.meta?.message || 'Davet gönderilemedi.');
          setSaving(false);
          return;
        }

        onSaved(result.meta?.message || `${name.trim()} başarıyla ekibe eklendi!`);
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Personel kaydedilemedi');
    } finally {
      setSaving(false);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-[10vh] p-4">
      <div className="absolute inset-0 bg-foreground-950/40" onClick={onClose} />
      <div className="relative bg-background-50 rounded-xl border border-background-200/70 w-full max-w-lg shadow-lg max-h-[80vh] overflow-y-auto">
        <div className="flex items-center justify-between px-5 py-4 border-b border-background-200/70">
          <h3 className="text-base font-semibold text-foreground-950">
            {isEdit ? 'Personeli Düzenle' : 'Ekibe Personel Davet Et'}
          </h3>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-background-100 text-foreground-500 transition-colors cursor-pointer"
          >
            <i className="ri-close-line"></i>
          </button>
        </div>

        {!isEdit && (
          <div className="mx-5 mt-4 flex items-start gap-3 p-3 bg-primary-50 border border-primary-200 rounded-lg">
            <div className="w-8 h-8 rounded-lg bg-primary-100 flex items-center justify-center flex-shrink-0">
              <i className="ri-mail-send-line text-primary-600 text-sm"></i>
            </div>
            <div>
              <p className="text-sm font-medium text-primary-800">Personel Davet Sistemi</p>
              <p className="text-xs text-primary-600 mt-0.5">
                Davet edilen personel, e-posta adresi ve belirlediğiniz şifre ile panele giriş yapabilir. 
                Şifreyi personelle güvenli bir şekilde paylaşın.
              </p>
            </div>
          </div>
        )}

        {error && (
          <div className="mx-5 mt-4 flex items-center gap-2 px-3 py-2.5 bg-accent-50 border border-accent-200 rounded-lg text-sm text-accent-700">
            <i className="ri-error-warning-line text-accent-600 flex-shrink-0"></i>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="px-5 py-4 space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground-700 mb-1.5">
              Ad Soyad <span className="text-accent-500">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-background-100 border border-background-200/70 rounded-lg text-foreground-900 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-300 focus:border-primary-300"
              placeholder="örn. Ahmet Yılmaz"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-foreground-700 mb-1.5">
                E-posta <span className="text-accent-500">*</span>
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-background-100 border border-background-200/70 rounded-lg text-foreground-900 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-300 focus:border-primary-300"
                placeholder="personel@ornek.com"
                disabled={isEdit}
              />
              {isEdit && (
                <p className="text-xs text-foreground-400 mt-1">E-posta adresi değiştirilemez</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground-700 mb-1.5">Telefon</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-background-100 border border-background-200/70 rounded-lg text-foreground-900 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-300 focus:border-primary-300"
                placeholder="(555) 123-4567"
              />
            </div>
          </div>

          {!isEdit && (
            <div>
              <label className="block text-sm font-medium text-foreground-700 mb-1.5">
                Geçici Şifre <span className="text-accent-500">*</span>
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-background-100 border border-background-200/70 rounded-lg text-foreground-900 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-300 focus:border-primary-300 pr-10"
                  placeholder="En az 6 karakter"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 w-7 h-7 flex items-center justify-center rounded text-foreground-400 hover:text-foreground-600 transition-colors cursor-pointer"
                >
                  <i className={showPassword ? 'ri-eye-off-line' : 'ri-eye-line'}></i>
                </button>
              </div>
              <p className="text-xs text-foreground-400 mt-1">
                Personel bu şifre ile giriş yapacak. Şifreyi güvenli bir şekilde iletin.
              </p>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-foreground-700 mb-1.5">
              Rol <span className="text-accent-500">*</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              {ROLES.map((r) => (
                <button
                  key={r.value}
                  type="button"
                  onClick={() => setRole(r.value)}
                  className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium border transition-colors cursor-pointer whitespace-nowrap ${
                    role === r.value
                      ? 'bg-primary-100 border-primary-300 text-primary-800'
                      : 'bg-background-100 border-background-200/70 text-foreground-600 hover:bg-background-200 hover:text-foreground-800'
                  }`}
                >
                  <i className={r.icon + ' text-base'}></i>
                  {r.label}
                </button>
              ))}
            </div>
            {role === 'admin' && (
              <p className="flex items-center gap-1.5 mt-2 text-xs text-accent-600">
                <i className="ri-alert-line"></i>
                Yönetici rolü tüm personele ve ayarlara erişim sağlar.
              </p>
            )}
          </div>

          {isEdit && (
            <div className="flex items-center gap-3">
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={active}
                  onChange={(e) => setActive(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-background-300 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-background-50 after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-background-50 after:border-background-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-secondary-500"></div>
              </label>
              <div>
                <p className="text-sm font-medium text-foreground-700">Aktif Personel</p>
                <p className="text-xs text-foreground-500">Pasif personel vardiyalara atanamaz</p>
              </div>
            </div>
          )}

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-foreground-600 hover:text-foreground-900 bg-background-100 hover:bg-background-200 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              İptal
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex items-center gap-2 px-4 py-2 text-sm font-medium bg-primary-500 hover:bg-primary-600 text-background-50 rounded-lg transition-colors cursor-pointer whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {saving ? (
                <>
                  <i className="ri-loader-4-line animate-spin"></i>
                  {isEdit ? 'Kaydediliyor...' : 'Davet gönderiliyor...'}
                </>
              ) : (
                <>
                  <i className={isEdit ? 'ri-save-line' : 'ri-mail-send-line'}></i>
                  {isEdit ? 'Değişiklikleri Kaydet' : 'Davet Gönder'}
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}