import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import StaffList from '@/pages/staff/components/StaffList';
import StaffForm from '@/pages/staff/components/StaffForm';

interface Staff {
  id: string;
  name: string;
  email: string | null;
  role: string;
  phone: string | null;
  active: boolean;
  created_at: string;
}

const ROLE_LABELS: Record<string, string> = {
  admin: 'Yönetici',
  manager: 'Müdür',
  mechanic: 'Teknisyen',
  receptionist: 'Resepsiyonist',
};

const ROLE_COLORS: Record<string, string> = {
  admin: 'bg-accent-100 text-accent-800',
  manager: 'bg-primary-100 text-primary-700',
  mechanic: 'bg-secondary-100 text-secondary-800',
  receptionist: 'bg-background-200 text-foreground-700',
};

const ROLE_ICONS: Record<string, string> = {
  admin: 'ri-shield-star-line',
  manager: 'ri-briefcase-line',
  mechanic: 'ri-tools-line',
  receptionist: 'ri-customer-service-2-line',
};

export default function StaffPage() {
  const [staffList, setStaffList] = useState<Staff[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [editData, setEditData] = useState<Staff | null>(null);
  const [detailMember, setDetailMember] = useState<Staff | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState('');

  const fetchStaff = useCallback(async () => {
    try {
      setLoading(true);
      setError('');

      const { data, error: sErr } = await supabase
        .from('staff')
        .select('*')
        .order('name', { ascending: true });

      if (sErr) throw sErr;
      setStaffList((data || []) as Staff[]);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Personel yüklenemedi');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchStaff();
  }, [fetchStaff]);

  const handleNew = () => {
    setEditData(null);
    setFormOpen(true);
  };

  const handleView = (member: Staff) => {
    setDetailMember(member);
  };

  const handleEdit = (member: Staff) => {
    setEditData(member);
    setFormOpen(true);
  };

  const handleSaved = (message?: string) => {
    setFormOpen(false);
    setEditData(null);
    if (message) {
      setSuccessMsg(message);
      setTimeout(() => setSuccessMsg(''), 4000);
    }
    fetchStaff();
  };

  const handleDelete = async (id: string) => {
    try {
      const { error: dErr } = await supabase.from('staff').delete().eq('id', id);
      if (dErr) throw dErr;
      setDeleteConfirm(null);
      setDetailMember(null);
      fetchStaff();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Personel silinemedi');
    }
  };

  const totalStaff = staffList.length;
  const activeStaff = staffList.filter((s) => s.active).length;
  const mechanicCount = staffList.filter((s) => s.role === 'mechanic').length;
  const adminCount = staffList.filter((s) => s.role === 'admin' || s.role === 'manager').length;

  const roleCounts = staffList.reduce<Record<string, number>>((acc, s) => {
    acc[s.role] = (acc[s.role] || 0) + 1;
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      {error && (
        <div className="flex items-center gap-2 px-4 py-3 bg-accent-50 border border-accent-200 rounded-lg text-sm text-accent-700">
          <i className="ri-error-warning-line text-accent-600"></i>
          {error}
          <button
            onClick={() => setError('')}
            className="ml-auto w-6 h-6 flex items-center justify-center rounded hover:bg-accent-100 text-accent-500 cursor-pointer"
          >
            <i className="ri-close-line"></i>
          </button>
        </div>
      )}

      {successMsg && (
        <div className="flex items-center gap-2 px-4 py-3 bg-secondary-50 border border-secondary-200 rounded-lg text-sm text-secondary-700">
          <i className="ri-checkbox-circle-line text-secondary-600"></i>
          {successMsg}
          <button
            onClick={() => setSuccessMsg('')}
            className="ml-auto w-6 h-6 flex items-center justify-center rounded hover:bg-secondary-100 text-secondary-500 cursor-pointer"
          >
            <i className="ri-close-line"></i>
          </button>
        </div>
      )}

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-foreground-950">Personel</h2>
          <p className="text-sm text-foreground-500 mt-0.5">
            {totalStaff} personel, {activeStaff} aktif
          </p>
        </div>
        <button
          onClick={handleNew}
          className="flex items-center gap-2 px-4 py-2 bg-primary-500 hover:bg-primary-600 text-background-50 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
        >
          <i className="ri-add-line text-base"></i>
          Personel Ekle
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-background-50 border border-background-200/70 rounded-xl p-4">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs text-foreground-500">Toplam Personel</p>
              <p className="text-xl font-bold text-foreground-950 mt-1">{totalStaff}</p>
            </div>
            <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 bg-primary-100">
              <i className="ri-team-line text-base text-primary-600"></i>
            </div>
          </div>
        </div>

        <div className="bg-background-50 border border-background-200/70 rounded-xl p-4">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs text-foreground-500">Aktif Personel</p>
              <p className="text-xl font-bold text-foreground-950 mt-1">{activeStaff}</p>
            </div>
            <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 bg-secondary-100">
              <i className="ri-user-follow-line text-base text-secondary-600"></i>
            </div>
          </div>
        </div>

        <div className="bg-background-50 border border-background-200/70 rounded-xl p-4">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs text-foreground-500">Teknisyen</p>
              <p className="text-xl font-bold text-foreground-950 mt-1">{mechanicCount}</p>
            </div>
            <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 bg-accent-100">
              <i className="ri-tools-line text-base text-accent-600"></i>
            </div>
          </div>
          <div className="flex flex-wrap gap-1 mt-2">
            {Object.entries(roleCounts).map(([r, count]) => (
              <span
                key={r}
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium ${ROLE_COLORS[r] || 'bg-background-200 text-foreground-700'}`}
              >
                <i className={(ROLE_ICONS[r] || 'ri-user-line') + ' text-[10px]'}></i>
                {ROLE_LABELS[r] || r}: {count}
              </span>
            ))}
          </div>
        </div>

        <div className="bg-background-50 border border-background-200/70 rounded-xl p-4">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs text-foreground-500">Yönetici</p>
              <p className="text-xl font-bold text-foreground-950 mt-1">{adminCount}</p>
            </div>
            <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 bg-primary-100">
              <i className="ri-shield-user-line text-base text-primary-600"></i>
            </div>
          </div>
        </div>
      </div>

      <StaffList
        staff={staffList}
        onView={handleView}
        onEdit={handleEdit}
        onDelete={(id) => setDeleteConfirm(id)}
        loading={loading}
      />

      <StaffForm
        open={formOpen}
        editData={editData}
        onClose={() => {
          setFormOpen(false);
          setEditData(null);
        }}
        onSaved={handleSaved}
      />

      {detailMember && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-foreground-950/40" onClick={() => setDetailMember(null)} />
          <div className="relative bg-background-50 rounded-xl border border-background-200/70 w-full max-w-md shadow-sm">
            <div className="flex items-center justify-between px-5 py-4 border-b border-background-200/70">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center">
                  <span className="text-sm font-bold text-primary-600">
                    {detailMember.name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase()}
                  </span>
                </div>
                <div>
                  <h3 className="text-base font-semibold text-foreground-950">{detailMember.name}</h3>
                  <p className="text-xs text-foreground-500">
                    Katılım: {new Date(detailMember.created_at).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' })}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setDetailMember(null)}
                className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-background-100 text-foreground-500 transition-colors cursor-pointer"
              >
                <i className="ri-close-line"></i>
              </button>
            </div>

            <div className="px-5 py-4 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-foreground-500 uppercase tracking-wide">E-posta</p>
                  <p className="text-sm text-foreground-700 mt-0.5">{detailMember.email || '—'}</p>
                </div>
                <div>
                  <p className="text-xs text-foreground-500 uppercase tracking-wide">Telefon</p>
                  <p className="text-sm text-foreground-700 mt-0.5">{detailMember.phone || '—'}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-foreground-500 uppercase tracking-wide">Rol</p>
                  <p className="mt-0.5">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${ROLE_COLORS[detailMember.role] || 'bg-background-200 text-foreground-700'}`}>
                      <i className={(ROLE_ICONS[detailMember.role] || 'ri-user-line') + ' text-[10px]'}></i>
                      {ROLE_LABELS[detailMember.role] || detailMember.role}
                    </span>
                  </p>
                </div>
                <div>
                  <p className="text-xs text-foreground-500 uppercase tracking-wide">Durum</p>
                  <p className="mt-0.5">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${
                      detailMember.active
                        ? 'bg-secondary-100 text-secondary-800'
                        : 'bg-background-200 text-foreground-500'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${detailMember.active ? 'bg-secondary-500' : 'bg-foreground-400'}`}></span>
                      {detailMember.active ? 'Aktif' : 'Pasif'}
                    </span>
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 px-5 py-4 border-t border-background-200/70">
              <button
                onClick={() => {
                  setDetailMember(null);
                  handleEdit(detailMember);
                }}
                className="px-4 py-2 text-sm font-medium bg-primary-500 hover:bg-primary-600 text-background-50 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
              >
                Düzenle
              </button>
            </div>
          </div>
        </div>
      )}

      {deleteConfirm && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-foreground-950/40" onClick={() => setDeleteConfirm(null)} />
          <div className="relative bg-background-50 rounded-xl border border-background-200/70 w-full max-w-sm p-5 shadow-sm">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-accent-100 flex items-center justify-center flex-shrink-0">
                <i className="ri-delete-bin-line text-accent-600 text-lg"></i>
              </div>
              <div>
                <h4 className="text-sm font-semibold text-foreground-950">Personeli Sil?</h4>
                <p className="text-xs text-foreground-500 mt-0.5">Bu işlem geri alınamaz.</p>
              </div>
            </div>
            <div className="flex items-center justify-end gap-3 mt-5">
              <button
                onClick={() => setDeleteConfirm(null)}
                className="px-4 py-2 text-sm font-medium text-foreground-600 hover:text-foreground-900 bg-background-100 hover:bg-background-200 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
              >
                İptal
              </button>
              <button
                onClick={() => handleDelete(deleteConfirm)}
                className="px-4 py-2 text-sm font-medium bg-accent-500 hover:bg-accent-600 text-background-50 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
              >
                Sil
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}