import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { clearStoredStaff, getStoredStaff, setStoredStaff } from '@/lib/session';

const AUTH_TIMEOUT_MS = 5000;

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);
  const [showContactModal, setShowContactModal] = useState(false);
  const [modalTitle, setModalTitle] = useState('');

  useEffect(() => {
    let cancelled = false;

    async function checkExistingSession() {
      try {
        const stored = getStoredStaff();

        const result = await Promise.race([
          supabase.auth.getSession(),
          new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error('AUTH_TIMEOUT')), AUTH_TIMEOUT_MS)
          ),
        ]);

        if (cancelled) return;

        if (result.data.session) {
          navigate('/', { replace: true });
          return;
        }

        if (stored) {
          clearStoredStaff();
        }
      } catch {
        // getSession timed out or failed — just show the login form
      } finally {
        if (!cancelled) {
          setChecking(false);
        }
      }
    }

    checkExistingSession();

    return () => {
      cancelled = true;
    };
  }, [navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email.trim() || !password.trim()) {
      setError('Lütfen hem e-posta hem de şifre giriniz.');
      return;
    }

    setLoading(true);
    try {
      // 1. Sign in with Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
        email: email.trim().toLowerCase(),
        password: password,
      });

      if (authError) {
        if (authError.message.includes('Invalid login credentials')) {
          setError('E-posta veya şifre hatalı.');
        } else {
          setError(authError.message);
        }
        setLoading(false);
        return;
      }

      if (!authData.user) {
        setError('Giriş başarısız. Lütfen tekrar deneyiniz.');
        setLoading(false);
        return;
      }

      // 2. Get staff record linked to this auth user
      const { data: staffData, error: staffError } = await supabase
        .from('staff')
        .select('id, name, email, role, avatar_url, shop_id')
        .eq('user_id', authData.user.id)
        .eq('active', true)
        .maybeSingle();

      if (staffError) {
        setError('Personel bilgisi alınamadı.');
        await supabase.auth.signOut();
        setLoading(false);
        return;
      }

      if (!staffData) {
        setError('Bu hesaba bağlı aktif bir personel kaydı bulunamadı. Lütfen mağaza yöneticinizle iletişime geçin.');
        await supabase.auth.signOut();
        setLoading(false);
        return;
      }

      // 3. Get shop name
      const { data: shopData } = await supabase
        .from('shops')
        .select('name')
        .eq('id', staffData.shop_id)
        .maybeSingle();

      // 4. Store in localStorage
      setStoredStaff({
        id: staffData.id,
        name: staffData.name,
        email: staffData.email,
        role: staffData.role,
        avatar_url: staffData.avatar_url,
        shop_id: staffData.shop_id,
        shop_name: shopData?.name || '',
      });

      navigate('/', { replace: true });
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Giriş başarısız. Lütfen tekrar deneyiniz.');
    } finally {
      setLoading(false);
    }
  };

  const openContactModal = (title: string) => {
    setModalTitle(title);
    setShowContactModal(true);
  };

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://storage.readdy-site.link/project_files/72ff7e3e-daf3-4e24-9fd1-0e495db6de64/b472a9f3-2f8b-4e34-8037-9ab00948c374_compressed_ChatGPT-Image-21-Haz-2026-10_43_28.webp"
            alt=""
            className="w-full h-full object-cover blur-sm scale-105"
          />
          <div className="absolute inset-0 bg-black/70"></div>
        </div>
        <i className="ri-loader-4-line animate-spin text-2xl text-background-50 z-10"></i>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Blurred background image */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://storage.readdy-site.link/project_files/72ff7e3e-daf3-4e24-9fd1-0e495db6de64/b472a9f3-2f8b-4e34-8037-9ab00948c374_compressed_ChatGPT-Image-21-Haz-2026-10_43_28.webp"
          alt=""
          className="w-full h-full object-cover blur-sm scale-105"
        />
        <div className="absolute inset-0 bg-black/70"></div>
      </div>

      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-xl bg-primary-500 flex items-center justify-center mx-auto mb-4">
            <i className="ri-tools-fill text-background-50 text-2xl"></i>
          </div>
          <h1 className="text-2xl font-heading font-bold text-background-50">ValixPro Kafe</h1>
          <p className="text-background-200 text-sm mt-1">Onarım dükkanınız paneline giriş yapın</p>
        </div>

        <div className="bg-background-50/10 backdrop-blur-md border border-background-50/20 rounded-xl p-8">
          <form onSubmit={handleLogin}>
            {error && (
              <div className="mb-5 p-3 rounded-lg bg-accent-100/60 text-accent-800 text-sm flex items-center gap-2">
                <i className="ri-error-warning-line text-base flex-shrink-0"></i>
                {error}
              </div>
            )}

            <div className="space-y-5">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-background-100 mb-1.5">
                  E-posta Adresi
                </label>
                <input
                  id="email"
                  type="email"
                  name="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@autofix.com"
                  className="w-full px-4 py-2.5 text-sm bg-background-50/80 border border-background-200 rounded-lg text-foreground-900 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-400/40 focus:border-primary-300 transition-colors"
                  autoComplete="email"
                />
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-background-100 mb-1.5">
                  Şifre
                </label>
                <input
                  id="password"
                  type="password"
                  name="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Şifrenizi giriniz"
                  className="w-full px-4 py-2.5 text-sm bg-background-50/80 border border-background-200 rounded-lg text-foreground-900 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-400/40 focus:border-primary-300 transition-colors"
                  autoComplete="current-password"
                />
              </div>
            </div>

            <div className="flex items-center justify-between mt-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className="w-4 h-4 rounded border-background-300 text-primary-500 focus:ring-primary-400/40 cursor-pointer" />
                <span className="text-sm text-background-200">Beni hatırla</span>
              </label>
              <button
                type="button"
                onClick={() => openContactModal('Şifre Yardımı')}
                className="text-sm text-primary-400 hover:text-primary-300 font-medium whitespace-nowrap cursor-pointer bg-transparent border-none p-0"
              >
                Şifremi unuttum?
              </button>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-6 py-2.5 px-4 bg-primary-500 hover:bg-primary-600 text-background-50 font-medium rounded-lg text-sm transition-colors disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer whitespace-nowrap flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <i className="ri-loader-4-line animate-spin text-base"></i>
                  Giriş yapılıyor...
                </>
              ) : (
                'Giriş Yap'
              )}
            </button>
          </form>

          <p className="text-center text-sm text-background-300 mt-5">
            Hesabınız yok mu?{' '}
            <button
              type="button"
              onClick={() => openContactModal('Mağaza Oluştur')}
              className="text-primary-400 hover:text-primary-300 font-medium whitespace-nowrap cursor-pointer bg-transparent border-none p-0"
            >
              Mağaza Oluştur
            </button>
          </p>
        </div>

        <p className="text-center text-xs text-background-400 mt-6">
          ValixPro Kafe — Kafe Yönetim Sistemi
        </p>
      </div>

      {/* Contact Info Modal */}
      {showContactModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Overlay */}
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowContactModal(false)}
          ></div>

          {/* Modal */}
          <div className="relative z-10 w-full max-w-sm bg-background-50 rounded-2xl shadow-lg overflow-hidden">
            {/* Header */}
            <div className="bg-primary-500 px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-background-50/20 flex items-center justify-center">
                  <i className="ri-customer-service-2-fill text-background-50 text-lg"></i>
                </div>
                <div>
                  <h3 className="text-background-50 font-heading font-semibold text-base">{modalTitle}</h3>
                  <p className="text-background-50/70 text-xs">Yönetici iletişim bilgileri</p>
                </div>
              </div>
              <button
                onClick={() => setShowContactModal(false)}
                className="w-8 h-8 rounded-lg bg-background-50/20 hover:bg-background-50/30 flex items-center justify-center cursor-pointer transition-colors"
              >
                <i className="ri-close-line text-background-50"></i>
              </button>
            </div>

            {/* Body */}
            <div className="px-6 py-5 space-y-4">
              {/* Email */}
              <div className="flex items-center gap-3 p-3 rounded-xl bg-background-100/60 border border-background-200/60">
                <div className="w-10 h-10 rounded-lg bg-primary-100 flex items-center justify-center flex-shrink-0">
                  <i className="ri-mail-fill text-primary-600 text-lg"></i>
                </div>
                <div className="min-w-0">
                  <p className="text-xs text-foreground-500 mb-0.5">E-posta</p>
                  <a
                    href="mailto:ozturkyigiteren@hotmail.com"
                    className="text-sm font-medium text-foreground-900 hover:text-primary-600 transition-colors break-all"
                  >
                    ozturkyigiteren@hotmail.com
                  </a>
                </div>
              </div>

              {/* Phone 1 */}
              <div className="flex items-center gap-3 p-3 rounded-xl bg-background-100/60 border border-background-200/60">
                <div className="w-10 h-10 rounded-lg bg-secondary-100 flex items-center justify-center flex-shrink-0">
                  <i className="ri-phone-fill text-secondary-600 text-lg"></i>
                </div>
                <div className="min-w-0">
                  <p className="text-xs text-foreground-500 mb-0.5">Telefon (Polonya)</p>
                  <a
                    href="tel:+48572341979"
                    className="text-sm font-medium text-foreground-900 hover:text-secondary-600 transition-colors whitespace-nowrap"
                  >
                    +48 572 341 979
                  </a>
                </div>
              </div>

              {/* Phone 2 */}
              <div className="flex items-center gap-3 p-3 rounded-xl bg-background-100/60 border border-background-200/60">
                <div className="w-10 h-10 rounded-lg bg-accent-100 flex items-center justify-center flex-shrink-0">
                  <i className="ri-phone-fill text-accent-600 text-lg"></i>
                </div>
                <div className="min-w-0">
                  <p className="text-xs text-foreground-500 mb-0.5">Telefon (Türkiye)</p>
                  <a
                    href="tel:+905356177427"
                    className="text-sm font-medium text-foreground-900 hover:text-accent-600 transition-colors whitespace-nowrap"
                  >
                    +90 535 617 74 27
                  </a>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="px-6 pb-5">
              <p className="text-xs text-foreground-400 text-center">
                Yeni mağaza oluşturmak veya şifre yardımı için yukarıdaki bilgilerden bize ulaşabilirsiniz.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}