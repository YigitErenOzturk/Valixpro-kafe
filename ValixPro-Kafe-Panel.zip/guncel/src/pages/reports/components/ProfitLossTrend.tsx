import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';

interface MonthlyData {
  month: string;
  gelir: number;
  gider: number;
  kar: number;
}

const monthNames = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];

interface Props {
  selectedYear: number;
}

export default function ProfitLossTrend({ selectedYear }: Props) {
  const [data, setData] = useState<MonthlyData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true);
        const startDate = `${selectedYear}-01-01`;
        const endDate = `${selectedYear}-12-31`;

        const { data: txs, error } = await supabase
          .from('transactions')
          .select('amount, transaction_date, type')
          .gte('transaction_date', startDate)
          .lte('transaction_date', endDate);

        if (error) throw error;

        const incomeMap: Record<string, number> = {};
        const expenseMap: Record<string, number> = {};

        for (let m = 0; m < 12; m++) {
          const key = `${selectedYear}-${String(m + 1).padStart(2, '0')}`;
          incomeMap[key] = 0;
          expenseMap[key] = 0;
        }

        (txs || []).forEach((tx: { amount: number; transaction_date: string; type: string }) => {
          const key = tx.transaction_date.substring(0, 7);
          const amount = Number(tx.amount);
          if (tx.type === 'income' && incomeMap[key] !== undefined) {
            incomeMap[key] += amount;
          } else if (tx.type === 'expense' && expenseMap[key] !== undefined) {
            expenseMap[key] += amount;
          }
        });

        const chartData: MonthlyData[] = Object.keys(incomeMap).map((key) => {
          const mIdx = parseInt(key.split('-')[1], 10) - 1;
          const gelir = Math.round(incomeMap[key]);
          const gider = Math.round(expenseMap[key]);
          return {
            month: monthNames[mIdx],
            gelir,
            gider,
            kar: gelir - gider,
          };
        });

        setData(chartData);
      } catch {
        setData([]);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, [selectedYear]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-72">
        <i className="ri-loader-4-line animate-spin text-xl text-foreground-400"></i>
      </div>
    );
  }

  return (
    <div className="h-72">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
          <defs>
            <linearGradient id="plGelir" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="oklch(var(--primary-500))" stopOpacity={0.25} />
              <stop offset="95%" stopColor="oklch(var(--primary-500))" stopOpacity={0} />
            </linearGradient>
            <linearGradient id="plGider" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="oklch(var(--accent-500))" stopOpacity={0.2} />
              <stop offset="95%" stopColor="oklch(var(--accent-500))" stopOpacity={0} />
            </linearGradient>
            <linearGradient id="plKar" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="oklch(var(--secondary-500))" stopOpacity={0.2} />
              <stop offset="95%" stopColor="oklch(var(--secondary-500))" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="oklch(var(--foreground-200) / 0.4)" vertical={false} />
          <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: 'oklch(var(--foreground-500))' }} />
          <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: 'oklch(var(--foreground-500))' }} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
          <Tooltip
            contentStyle={{
              backgroundColor: 'oklch(var(--background-50))',
              border: '1px solid oklch(var(--background-200) / 0.7)',
              borderRadius: '8px',
              fontSize: '12px',
              color: 'oklch(var(--foreground-900))',
            }}
            formatter={(value: number, name: string) => {
              const labels: Record<string, string> = { gelir: 'Gelir', gider: 'Gider', kar: 'Net Kâr' };
              return [`$${value.toLocaleString('tr-TR')}`, labels[name] || name];
            }}
          />
          <Legend
            formatter={(value: string) => {
              const labels: Record<string, string> = { gelir: 'Gelir', gider: 'Gider', kar: 'Net Kâr' };
              return <span style={{ color: 'oklch(var(--foreground-700))', fontSize: '12px' }}>{labels[value] || value}</span>;
            }}
          />
          <Area type="monotone" dataKey="gelir" stroke="oklch(var(--primary-500))" strokeWidth={2} fill="url(#plGelir)" />
          <Area type="monotone" dataKey="gider" stroke="oklch(var(--accent-500))" strokeWidth={2} fill="url(#plGider)" />
          <Area type="monotone" dataKey="kar" stroke="oklch(var(--secondary-500))" strokeWidth={2} fill="url(#plKar)" strokeDasharray="5 5" />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}