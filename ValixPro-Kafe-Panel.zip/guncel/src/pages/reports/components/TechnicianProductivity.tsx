import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

interface TechData {
  id: string;
  name: string;
  completed: number;
  total: number;
  revenue: number;
}

interface Props {
  selectedYear: number;
}

export default function TechnicianProductivity({ selectedYear }: Props) {
  const [data, setData] = useState<TechData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true);
        const startDate = `${selectedYear}-01-01`;
        const endDate = `${selectedYear}-12-31`;

        const [staffRes, apptRes] = await Promise.all([
          supabase.from('staff').select('id, name').eq('active', true),
          supabase
            .from('appointments')
            .select('staff_id, status')
            .gte('date', startDate)
            .lte('date', endDate),
        ]);

        if (staffRes.error) throw staffRes.error;
        if (apptRes.error) throw apptRes.error;

        const staffList = (staffRes.data || []) as { id: string; name: string }[];
        const appointments = (apptRes.data || []) as { staff_id: string; status: string }[];

        const staffStats: Record<string, { completed: number; total: number }> = {};
        staffList.forEach((s) => {
          staffStats[s.id] = { completed: 0, total: 0 };
        });

        appointments.forEach((a) => {
          if (!a.staff_id || !staffStats[a.staff_id]) return;
          staffStats[a.staff_id].total += 1;
          if (a.status === 'completed') {
            staffStats[a.staff_id].completed += 1;
          }
        });

        const result: TechData[] = staffList
          .filter((s) => staffStats[s.id] && staffStats[s.id].total > 0)
          .map((s) => {
            const stats = staffStats[s.id];
            return {
              id: s.id,
              name: s.name,
              completed: stats.completed,
              total: stats.total,
              revenue: 0,
            };
          })
          .sort((a, b) => b.total - a.total);

        setData(result);
      } catch {
        setData([]);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, [selectedYear]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-48">
        <i className="ri-loader-4-line animate-spin text-xl text-foreground-400"></i>
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center h-48 text-sm text-foreground-400">
        Bu yıl için teknisyen verisi bulunamadı.
      </div>
    );
  }

  const maxTotal = Math.max(...data.map((d) => d.total), 1);

  return (
    <div className="space-y-4">
      {data.map((tech) => {
        const completionRate = tech.total > 0 ? Math.round((tech.completed / tech.total) * 100) : 0;
        const barPct = Math.round((tech.total / maxTotal) * 100);

        return (
          <div key={tech.id} className="flex items-center gap-4">
            <div className="w-9 h-9 rounded-full bg-primary-100 flex items-center justify-center flex-shrink-0">
              <span className="text-xs font-bold text-primary-700">
                {tech.name.charAt(0).toUpperCase()}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium text-foreground-800 truncate">{tech.name}</span>
                <span className="text-xs text-foreground-500 whitespace-nowrap ml-2">
                  {tech.completed}/{tech.total} tamamlandı
                </span>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-2 bg-background-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary-500 rounded-full transition-all duration-700"
                    style={{ width: `${barPct}%` }}
                  ></div>
                </div>
                <span className="text-xs font-semibold text-foreground-600 w-9 text-right whitespace-nowrap">
                  %{completionRate}
                </span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}