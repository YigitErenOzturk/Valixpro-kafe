import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';

interface CategoryData {
  name: string;
  gelir: number;
  gider: number;
  net: number;
}

const BAR_COLORS = [
  'oklch(var(--primary-500))',
  'oklch(var(--accent-500))',
  'oklch(var(--secondary-500))',
  'oklch(var(--primary-400))',
  'oklch(var(--accent-400))',
  'oklch(var(--secondary-400))',
  'oklch(var(--primary-300))',
  'oklch(var(--accent-300))',
];

interface Props {
  selectedYear: number;
}

export default function CategoryRevenueChart({ selectedYear }: Props) {
  const [data, setData] = useState<CategoryData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true);
        const startDate = `${selectedYear}-01-01`;
        const endDate = `${selectedYear}-12-31`;

        const { data: txs, error } = await supabase
          .from('transactions')
          .select('amount, category, type')
          .gte('transaction_date', startDate)
          .lte('transaction_date', endDate);

        if (error) throw error;

        const catMap: Record<string, { income: number; expense: number }> = {};

        (txs || []).forEach((tx: { amount: number; category: string; type: string }) => {
          const cat = tx.category || 'Diğer';
          if (!catMap[cat]) catMap[cat] = { income: 0, expense: 0 };
          if (tx.type === 'income') {
            catMap[cat].income += Number(tx.amount);
          } else {
            catMap[cat].expense += Number(tx.amount);
          }
        });

        const chartData: CategoryData[] = Object.entries(catMap)
          .map(([name, vals]) => ({
            name,
            gelir: Math.round(vals.income),
            gider: Math.round(vals.expense),
            net: Math.round(vals.income - vals.expense),
          }))
          .sort((a, b) => b.gelir - a.gelir || b.net - a.net)
          .slice(0, 8);

        setData(chartData);
      } catch {
        setData([]);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, [selectedYear]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <i className="ri-loader-4-line animate-spin text-xl text-foreground-400"></i>
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 text-sm text-foreground-400">
        Bu yıl için veri bulunamadı.
      </div>
    );
  }

  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ top: 5, right: 20, left: 60, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="oklch(var(--foreground-200) / 0.4)" horizontal={false} />
          <XAxis type="number" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: 'oklch(var(--foreground-500))' }} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
          <YAxis type="category" dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: 'oklch(var(--foreground-700))' }} width={90} />
          <Tooltip
            contentStyle={{
              backgroundColor: 'oklch(var(--background-50))',
              border: '1px solid oklch(var(--background-200) / 0.7)',
              borderRadius: '8px',
              fontSize: '12px',
              color: 'oklch(var(--foreground-900))',
            }}
            formatter={(value: number, name: string) => {
              const labels: Record<string, string> = { gelir: 'Gelir', gider: 'Gider', net: 'Net' };
              return [`$${value.toLocaleString('tr-TR')}`, labels[name] || name];
            }}
          />
          <Bar dataKey="gelir" radius={[0, 4, 4, 0]} maxBarSize={20}>
            {data.map((_, idx) => (
              <Cell key={`cell-${idx}`} fill={BAR_COLORS[idx % BAR_COLORS.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}