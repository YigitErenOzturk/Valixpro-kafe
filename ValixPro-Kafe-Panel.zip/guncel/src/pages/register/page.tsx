import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';

const AUTH_TIMEOUT_MS = 5000;

export default function Register() {
  const navigate = useNavigate();
  const [shopName, setShopName] = useState('');
  const [staffName, setStaffName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    let cancelled = false;

    async function checkExistingSession() {
      try {
        const result = await Promise.race([
          supabase.auth.getSession(),
          new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error('AUTH_TIMEOUT')), AUTH_TIMEOUT_MS)
          ),
        ]);
        if (cancelled) return;
        if (result.data.session) {
          navigate('/');
          return;
        }
      } catch {
        // timed out or failed — just show the form
      } finally {
        if (!cancelled) setChecking(false);
      }
    }

    checkExistingSession();
    return () => {
      cancelled = true;
    };
  }, [navigate]);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!shopName.trim() || !staffName.trim() || !email.trim() || !password.trim() || !confirmPassword.trim()) {
      setError('Lütfen tüm alanları doldurun.');
      return;
    }

    if (password.length < 6) {
      setError('Şifre en az 6 karakter olmalıdır.');
      return;
    }

    if (password !== confirmPassword) {
      setError('Şifreler eşleşmiyor.');
      return;
    }

    setLoading(true);
    try {
      // Step 1: Create auth user via Supabase signUp
      const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
        email: email.trim().toLowerCase(),
        password: password,
        options: {
          data: { name: staffName.trim() },
        },
      });

      if (signUpError) {
        const msg = signUpError.message.toLowerCase();
        if (msg.includes('already') || msg.includes('registered') || msg.includes('exists')) {
          setError('Bu e-posta zaten kayıtlı. Lütfen giriş sayfasından giriş yapın.');
        } else if (msg.includes('password')) {
          setError('Şifre en az 6 karakter olmalıdır.');
        } else {
          setError(`Kayıt hatası: ${signUpError.message}`);
        }
        setLoading(false);
        return;
      }

      // Supabase may return a fake user (no session, empty identities) when the email already exists
      if (signUpData.user && Array.isArray(signUpData.user.identities) && signUpData.user.identities.length === 0) {
        setError('Bu e-posta zaten kayıtlı. Lütfen giriş sayfasından giriş yapın.');
        setLoading(false);
        return;
      }

      if (!signUpData.session) {
        setError('Kayıt yapıldı fakat oturum oluşturulamadı. Lütfen giriş sayfasından giriş yapın.');
        setLoading(false);
        return;
      }

      // Step 2: Call edge function to create shop + staff records
      const { data: fnData, error: fnError } = await supabase.functions.invoke('register-shop', {
        body: {
          shopName: shopName.trim(),
          staffName: staffName.trim(),
        },
      });

      if (fnError) {
        setError(fnError.message || 'Mağaza oluşturulurken hata oluştu.');
        setLoading(false);
        return;
      }

      // Store staff info in localStorage
      localStorage.setItem('autofix_staff', JSON.stringify({
        id: fnData.data.staff.id,
        name: fnData.data.staff.name,
        email: fnData.data.staff.email,
        role: fnData.data.staff.role,
        shop_id: fnData.data.staff.shop_id,
        shop_name: fnData.data.shop.name,
      }));

      navigate('/');
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Bağlantı hatası. Lütfen tekrar deneyin.');
    } finally {
      setLoading(false);
    }
  };

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://storage.readdy-site.link/project_files/72ff7e3e-daf3-4e24-9fd1-0e495db6de64/b472a9f3-2f8b-4e34-8037-9ab00948c374_compressed_ChatGPT-Image-21-Haz-2026-10_43_28.webp"
            alt=""
            className="w-full h-full object-cover blur-sm scale-105"
          />
          <div className="absolute inset-0 bg-black/50"></div>
        </div>
        <i className="ri-loader-4-line animate-spin text-2xl text-background-50 z-10"></i>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Blurred background image */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://storage.readdy-site.link/project_files/72ff7e3e-daf3-4e24-9fd1-0e495db6de64/b472a9f3-2f8b-4e34-8037-9ab00948c374_compressed_ChatGPT-Image-21-Haz-2026-10_43_28.webp"
          alt=""
          className="w-full h-full object-cover blur-sm scale-105"
        />
        <div className="absolute inset-0 bg-black/50"></div>
      </div>

      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-xl bg-primary-500 flex items-center justify-center mx-auto mb-4">
            <i className="ri-store-2-fill text-background-50 text-2xl"></i>
          </div>
          <h1 className="text-2xl font-heading font-bold text-background-50">Yeni Mağaza Kaydı</h1>
          <p className="text-background-200 text-sm mt-1">Kafeniz için yönetim paneli oluşturun</p>
        </div>

        <div className="bg-background-50/10 backdrop-blur-md border border-background-50/20 rounded-xl p-8">
          <form onSubmit={handleRegister}>
            {error && (
              <div className="mb-5 p-3 rounded-lg bg-accent-100/60 text-accent-800 text-sm flex items-center gap-2">
                <i className="ri-error-warning-line text-base flex-shrink-0"></i>
                {error}
              </div>
            )}

            <div className="space-y-4">
              <div>
                <label htmlFor="shopName" className="block text-sm font-medium text-background-100 mb-1.5">
                  Mağaza Adı
                </label>
                <input
                  id="shopName"
                  type="text"
                  name="shopName"
                  value={shopName}
                  onChange={(e) => setShopName(e.target.value)}
                  placeholder="Örn: Merkez Kahve"
                  className="w-full px-4 py-2.5 text-sm bg-background-50/80 border border-background-200 rounded-lg text-foreground-900 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-400/40 focus:border-primary-300 transition-colors"
                  autoComplete="organization"
                />
              </div>

              <div>
                <label htmlFor="staffName" className="block text-sm font-medium text-background-100 mb-1.5">
                  Adınız Soyadınız
                </label>
                <input
                  id="staffName"
                  type="text"
                  name="staffName"
                  value={staffName}
                  onChange={(e) => setStaffName(e.target.value)}
                  placeholder="Ahmet Yılmaz"
                  className="w-full px-4 py-2.5 text-sm bg-background-50/80 border border-background-200 rounded-lg text-foreground-900 placeholder:text-foreground-400 focus:outline-none focus:ring-ring-primary-400/40 focus:border-primary-300 transition-colors"
                  autoComplete="name"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-background-100 mb-1.5">
                  E-posta Adresi
                </label>
                <input
                  id="email"
                  type="email"
                  name="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="ornek@email.com"
                  className="w-full px-4 py-2.5 text-sm bg-background-50/80 border border-background-200 rounded-lg text-foreground-900 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-400/40 focus:border-primary-300 transition-colors"
                  autoComplete="email"
                />
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-background-100 mb-1.5">
                  Şifre
                </label>
                <input
                  id="password"
                  type="password"
                  name="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="En az 6 karakter"
                  className="w-full px-4 py-2.5 text-sm bg-background-50/80 border border-background-200 rounded-lg text-foreground-900 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-400/40 focus:border-primary-300 transition-colors"
                  autoComplete="new-password"
                />
              </div>

              <div>
                <label htmlFor="confirmPassword" className="block text-sm font-medium text-background-100 mb-1.5">
                  Şifreyi Onayla
                </label>
                <input
                  id="confirmPassword"
                  type="password"
                  name="confirmPassword"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Şifreyi tekrar girin"
                  className="w-full px-4 py-2.5 text-sm bg-background-50/80 border border-background-200 rounded-lg text-foreground-900 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-400/40 focus:border-primary-300 transition-colors"
                  autoComplete="new-password"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-6 py-2.5 px-4 bg-primary-500 hover:bg-primary-600 text-background-50 font-medium rounded-lg text-sm transition-colors disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer whitespace-nowrap flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <i className="ri-loader-4-line animate-spin text-base"></i>
                  Kayıt yapılıyor...
                </>
              ) : (
                'Mağaza Oluştur'
              )}
            </button>
          </form>

          <p className="text-center text-sm text-background-300 mt-5">
            Zaten bir hesabınız var mı?{' '}
            <Link to="/login" className="text-primary-400 hover:text-primary-300 font-medium whitespace-nowrap">
              Giriş Yap
            </Link>
          </p>
        </div>

        <p className="text-center text-xs text-background-400 mt-6">
          ValixPro Kafe — Kafe Yönetim Sistemi
        </p>
      </div>
    </div>
  );
}