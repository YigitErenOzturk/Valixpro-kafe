import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

const DAYS = [
  { key: 'pazartesi', label: 'Pazartesi' },
  { key: 'sali', label: 'Salı' },
  { key: 'carsamba', label: 'Çarşamba' },
  { key: 'persembe', label: 'Perşembe' },
  { key: 'cuma', label: 'Cuma' },
  { key: 'cumartesi', label: 'Cumartesi' },
  { key: 'pazar', label: 'Pazar' },
];

const NOTIF_PREFS = [
  { key: 'emailNotifications', label: 'E-posta Bildirimleri', desc: 'Yeni sipariş ve günlük özet bildirimlerini e-posta ile alın', icon: 'ri-mail-line' },
];

interface BusinessHour {
  open: string;
  close: string;
  closed: boolean;
}

interface NotificationPrefs {
  emailNotifications: boolean;
  appointmentReminders: boolean;
  invoicePaidNotifications: boolean;
  lowStockAlerts: boolean;
}

interface ShopData {
  id: number;
  shop_name: string;
  address: string;
  phone: string;
  email: string;
  tax_number: string;
  avatar_url: string | null;
  business_hours: Record<string, BusinessHour>;
  notification_prefs: NotificationPrefs;
}

function ensureBusinessHours(raw: unknown): Record<string, BusinessHour> {
  if (typeof raw !== 'object' || raw === null) return {};
  return raw as Record<string, BusinessHour>;
}

function ensureNotificationPrefs(raw: unknown): NotificationPrefs {
  if (typeof raw !== 'object' || raw === null) {
    return {
      emailNotifications: true,
      appointmentReminders: true,
      invoicePaidNotifications: false,
      lowStockAlerts: true,
    };
  }
  const r = raw as Record<string, unknown>;
  return {
    emailNotifications: r.emailNotifications !== false,
    appointmentReminders: r.appointmentReminders !== false,
    invoicePaidNotifications: r.invoicePaidNotifications === true,
    lowStockAlerts: r.lowStockAlerts !== false,
  };
}

function resizeImageToBase64(file: File, maxDim = 256, quality = 0.75): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const reader = new FileReader();
    reader.onload = (e) => {
      img.src = e.target?.result as string;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);

    img.onload = () => {
      const canvas = document.createElement('canvas');
      let { width, height } = img;
      if (width > height) {
        if (width > maxDim) { height *= maxDim / width; width = maxDim; }
      } else {
        if (height > maxDim) { width *= maxDim / height; height = maxDim; }
      }
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) { reject(new Error('Canvas context oluşturulamadı')); return; }
      ctx.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
    img.onerror = reject;
  });
}

export default function Settings() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [shop, setShop] = useState<ShopData | null>(null);
  const [shopId, setShopId] = useState<string>('');

  // Load shop_id from localStorage
  useEffect(() => {
    const stored = localStorage.getItem('autofix_staff');
    if (stored) {
      const s = JSON.parse(stored);
      setShopId(s.shop_id || '');
    }
  }, []);

  const [form, setForm] = useState({
    shop_name: '',
    address: '',
    phone: '',
    email: '',
    tax_number: '',
    avatar_url: '',
  });

  const [hours, setHours] = useState<Record<string, BusinessHour>>({});
  const [prefs, setPrefs] = useState<NotificationPrefs>({
    emailNotifications: true,
    appointmentReminders: true,
    invoicePaidNotifications: false,
    lowStockAlerts: true,
  });

  useEffect(() => {
    loadSettings();
  }, []);

  async function loadSettings() {
    setLoading(true);
    setError('');
    try {
      const { data, error: err } = await supabase
        .from('shop_settings')
        .select('*')
        .maybeSingle();

      if (err) throw err;

      if (data) {
        const s: ShopData = {
          id: data.id,
          shop_name: data.shop_name || 'ValixPro Kafe',
          address: data.address || '',
          phone: data.phone || '',
          email: data.email || '',
          tax_number: data.tax_number || '',
          avatar_url: data.avatar_url || null,
          business_hours: ensureBusinessHours(data.business_hours),
          notification_prefs: ensureNotificationPrefs(data.notification_prefs),
        };
        setShop(s);
        setForm({
          shop_name: s.shop_name,
          address: s.address,
          phone: s.phone,
          email: s.email,
          tax_number: s.tax_number,
          avatar_url: s.avatar_url || '',
        });
        setHours(s.business_hours);
        setPrefs(s.notification_prefs);
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Ayarlar yüklenirken bir hata oluştu.');
    } finally {
      setLoading(false);
    }
  }

  const handleFormChange = (field: string, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleLogoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setError('Lütfen bir görsel dosyası seçiniz (JPEG, PNG).');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setError("Dosya boyutu 5MB'dan büyük olamaz.");
      return;
    }
    try {
      setError('');
      const base64 = await resizeImageToBase64(file, 256, 0.75);
      setForm((prev) => ({ ...prev, avatar_url: base64 }));
    } catch {
      setError('Görsel yüklenirken bir hata oluştu.');
    }
  };

  const handleRemoveLogo = () => {
    setForm((prev) => ({ ...prev, avatar_url: '' }));
  };

  const handleHourChange = (dayKey: string, field: keyof BusinessHour, value: string | boolean) => {
    setHours((prev) => {
      const current = prev[dayKey] || { open: '08:00', close: '18:00', closed: false };
      return {
        ...prev,
        [dayKey]: { ...current, [field]: value },
      };
    });
  };

  const togglePref = (key: string) => {
    setPrefs((prev) => ({ ...prev, [key]: !prev[key as keyof NotificationPrefs] }));
  };

  const handleSave = async () => {
    setSaving(true);
    setError('');
    setSuccess('');
    try {
      const payload = {
        shop_name: form.shop_name,
        address: form.address,
        phone: form.phone,
        email: form.email,
        tax_number: form.tax_number,
        avatar_url: form.avatar_url || null,
        business_hours: hours,
        notification_prefs: prefs,
        updated_at: new Date().toISOString(),
      };

      if (shop?.id) {
        const { data, error: err } = await supabase
          .from('shop_settings')
          .update(payload)
          .eq('id', shop.id)
          .select()
          .single();
        if (err) {
          console.error('Update error:', err);
          throw new Error(err.message || 'Güncelleme sırasında bir hata oluştu.');
        }
        if (data) {
          setShop({
            id: data.id,
            shop_name: data.shop_name || '',
            address: data.address || '',
            phone: data.phone || '',
            email: data.email || '',
            tax_number: data.tax_number || '',
            avatar_url: data.avatar_url || null,
            business_hours: ensureBusinessHours(data.business_hours),
            notification_prefs: ensureNotificationPrefs(data.notification_prefs),
          });
        }
      } else {
        const { data, error: err } = await supabase
          .from('shop_settings')
          .insert({ ...payload, shop_id: shopId, created_at: new Date().toISOString() })
          .select()
          .single();
        if (err) {
          console.error('Insert error:', err);
          throw new Error(err.message || 'Kaydetme sırasında bir hata oluştu.');
        }
        if (data) {
          setShop({
            id: data.id,
            shop_name: data.shop_name || '',
            address: data.address || '',
            phone: data.phone || '',
            email: data.email || '',
            tax_number: data.tax_number || '',
            avatar_url: data.avatar_url || null,
            business_hours: ensureBusinessHours(data.business_hours),
            notification_prefs: ensureNotificationPrefs(data.notification_prefs),
          });
        }
      }

      setSuccess('Ayarlar başarıyla kaydedildi.');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Kaydetme sırasında bir hata oluştu.';
      console.error('Save error:', err);
      setError(msg);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <i className="ri-loader-4-line animate-spin text-2xl text-primary-500"></i>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-4xl">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-bold text-foreground-900">Ayarlar</h1>
        <button
          onClick={handleSave}
          disabled={saving}
          className="px-4 py-2 bg-primary-500 hover:bg-primary-600 text-background-50 text-sm font-medium rounded-lg transition-colors disabled:opacity-60 cursor-pointer whitespace-nowrap flex items-center gap-2"
        >
          {saving ? (
            <>
              <i className="ri-loader-4-line animate-spin"></i> Kaydediliyor...
            </>
          ) : (
            <>
              <i className="ri-save-line"></i> Değişiklikleri Kaydet
            </>
          )}
        </button>
      </div>

      {error && (
        <div className="mb-5 p-3 rounded-lg bg-accent-100/60 text-accent-800 text-sm flex items-center gap-2">
          <i className="ri-error-warning-line text-base flex-shrink-0"></i>
          {error}
        </div>
      )}

      {success && (
        <div className="mb-5 p-3 rounded-lg bg-primary-100/60 text-primary-800 text-sm flex items-center gap-2">
          <i className="ri-checkbox-circle-line text-base flex-shrink-0"></i>
          {success}
        </div>
      )}

      {/* Dükkan Bilgileri */}
      <section className="bg-background-50 border border-background-200/70 rounded-xl p-6 mb-5">
        <div className="flex items-center gap-2.5 mb-5">
          <span className="w-8 h-8 rounded-lg bg-primary-100 flex items-center justify-center text-primary-600">
            <i className="ri-store-2-line text-base"></i>
          </span>
          <h2 className="text-base font-semibold text-foreground-900">Dükkan Bilgileri</h2>
        </div>

        {/* Shop Logo Upload */}
        <div className="mb-5">
          <label className="block text-sm font-medium text-foreground-700 mb-2">Dükkan Logosu</label>
          <div className="flex items-start gap-4">
            <div className="w-20 h-20 rounded-xl bg-background-100 border border-background-200/70 flex items-center justify-center overflow-hidden flex-shrink-0">
              {form.avatar_url ? (
                <img src={form.avatar_url} alt="Dükkan logosu" className="w-full h-full object-cover" />
              ) : (
                <i className="ri-store-2-line text-2xl text-foreground-300"></i>
              )}
            </div>
            <div className="flex flex-col gap-2">
              <label className="inline-flex items-center gap-2 px-3 py-2 bg-secondary-500 hover:bg-secondary-600 text-background-50 text-sm font-medium rounded-lg cursor-pointer transition-colors whitespace-nowrap">
                <i className="ri-upload-cloud-2-line text-base"></i>
                Logo Yükle
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleLogoSelect}
                />
              </label>
              {form.avatar_url && (
                <button
                  onClick={handleRemoveLogo}
                  className="inline-flex items-center gap-2 px-3 py-2 text-sm text-accent-600 hover:bg-accent-50 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-delete-bin-line text-base"></i>
                  Logoyu Kaldır
                </button>
              )}
              <p className="text-xs text-foreground-400">JPEG veya PNG, max 5MB</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-foreground-700 mb-1.5">Dükkan Adı</label>
            <input
              type="text"
              value={form.shop_name}
              onChange={(e) => handleFormChange('shop_name', e.target.value)}
              className="w-full px-4 py-2.5 text-sm bg-background-50 border border-background-200 rounded-lg text-foreground-900 focus:outline-none focus:ring-2 focus:ring-primary-400/40 focus:border-primary-300 transition-colors"
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-foreground-700 mb-1.5">Adres</label>
            <input
              type="text"
              value={form.address}
              onChange={(e) => handleFormChange('address', e.target.value)}
              placeholder="Sokak, Mahalle, Şehir"
              className="w-full px-4 py-2.5 text-sm bg-background-50 border border-background-200 rounded-lg text-foreground-900 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-400/40 focus:border-primary-300 transition-colors"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground-700 mb-1.5">Telefon</label>
            <input
              type="tel"
              value={form.phone}
              onChange={(e) => handleFormChange('phone', e.target.value)}
              placeholder="+90 212 555 01 23"
              className="w-full px-4 py-2.5 text-sm bg-background-50 border border-background-200 rounded-lg text-foreground-900 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-400/40 focus:border-primary-300 transition-colors"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground-700 mb-1.5">E-posta</label>
            <input
              type="email"
              value={form.email}
              onChange={(e) => handleFormChange('email', e.target.value)}
              placeholder="info@autofix.com"
              className="w-full px-4 py-2.5 text-sm bg-background-50 border border-background-200 rounded-lg text-foreground-900 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-400/40 focus:border-primary-300 transition-colors"
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-foreground-700 mb-1.5">Vergi Numarası</label>
            <input
              type="text"
              value={form.tax_number}
              onChange={(e) => handleFormChange('tax_number', e.target.value)}
              placeholder="TR1234567890"
              className="w-full px-4 py-2.5 text-sm bg-background-50 border border-background-200 rounded-lg text-foreground-900 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-400/40 focus:border-primary-300 transition-colors"
            />
          </div>
        </div>
      </section>

      {/* Çalışma Saatleri */}
      <section className="bg-background-50 border border-background-200/70 rounded-xl p-6 mb-5">
        <div className="flex items-center gap-2.5 mb-5">
          <span className="w-8 h-8 rounded-lg bg-accent-100 flex items-center justify-center text-accent-600">
            <i className="ri-time-line text-base"></i>
          </span>
          <h2 className="text-base font-semibold text-foreground-900">Çalışma Saatleri</h2>
        </div>

        <div className="space-y-3">
          {DAYS.map((day) => {
            const h = hours[day.key] || { open: '08:00', close: '18:00', closed: false };
            return (
              <div
                key={day.key}
                className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4 p-3 rounded-lg border border-background-100 bg-background-50"
              >
                <div className="sm:w-28 flex-shrink-0">
                  <p className="text-sm font-medium text-foreground-700">{day.label}</p>
                </div>
                <div className="flex-1 flex items-center gap-3">
                  <input
                    type="time"
                    value={h.open}
                    disabled={h.closed}
                    onChange={(e) => handleHourChange(day.key, 'open', e.target.value)}
                    className="w-28 px-3 py-2 text-sm bg-background-50 border border-background-200 rounded-lg text-foreground-900 focus:outline-none focus:ring-2 focus:ring-primary-400/40 focus:border-primary-300 transition-colors disabled:opacity-50"
                  />
                  <span className="text-sm text-foreground-400">—</span>
                  <input
                    type="time"
                    value={h.close}
                    disabled={h.closed}
                    onChange={(e) => handleHourChange(day.key, 'close', e.target.value)}
                    className="w-28 px-3 py-2 text-sm bg-background-50 border border-background-200 rounded-lg text-foreground-900 focus:outline-none focus:ring-2 focus:ring-primary-400/40 focus:border-primary-300 transition-colors disabled:opacity-50"
                  />
                </div>
                <div className="flex items-center gap-2 sm:ml-auto">
                  <button
                    onClick={() => handleHourChange(day.key, 'closed', !h.closed)}
                    className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                      h.closed
                        ? 'bg-accent-100 text-accent-700'
                        : 'bg-background-100 text-foreground-500'
                    }`}
                  >
                    <span
                      className={`w-5 h-3 rounded-full inline-flex items-center transition-colors ${
                        h.closed ? 'bg-accent-500' : 'bg-background-200'
                      }`}
                    >
                      <span
                        className={`block w-2.5 h-2.5 rounded-full bg-background-50 transition-transform ${
                          h.closed ? 'translate-x-[8px]' : 'translate-x-0.5'
                        }`}
                      />
                    </span>
                    {h.closed ? 'Kapalı' : 'Açık'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Bildirim Tercihleri */}
      <section className="bg-background-50 border border-background-200/70 rounded-xl p-6 mb-5">
        <div className="flex items-center gap-2.5 mb-5">
          <span className="w-8 h-8 rounded-lg bg-secondary-100 flex items-center justify-center text-secondary-600">
            <i className="ri-notification-3-line text-base"></i>
          </span>
          <h2 className="text-base font-semibold text-foreground-900">Bildirim Kanalı</h2>
        </div>

        <p className="text-sm text-foreground-500 mb-5">Müşterilere hangi kanaldan bildirim gönderileceğini seçin.</p>

        <div className="space-y-3">
          {NOTIF_PREFS.map((pref) => {
            const isOn = prefs[pref.key as keyof NotificationPrefs];
            return (
              <div
                key={pref.key}
                className="flex items-center justify-between p-4 rounded-lg border border-background-100 bg-background-50"
              >
                <div className="flex items-center gap-3">
                  <span className="w-10 h-10 rounded-lg bg-background-100 flex items-center justify-center text-foreground-500">
                    <i className={`${pref.icon} text-lg`}></i>
                  </span>
                  <div>
                    <p className="text-sm font-medium text-foreground-900">{pref.label}</p>
                    <p className="text-xs text-foreground-500 mt-0.5">{pref.desc}</p>
                  </div>
                </div>
                <button
                  onClick={() => togglePref(pref.key)}
                  className={`relative w-11 h-6 rounded-full transition-colors cursor-pointer flex-shrink-0 ${
                    isOn ? 'bg-primary-500' : 'bg-background-200'
                  }`}
                  aria-label={isOn ? `${pref.label} kapat` : `${pref.label} aç`}
                >
                  <span
                    className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-background-50 transition-transform ${
                      isOn ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {/* E-posta Bildirim İçerikleri */}
      <section className="bg-background-50 border border-background-200/70 rounded-xl p-6">
        <div className="flex items-center gap-2.5 mb-5">
          <span className="w-8 h-8 rounded-lg bg-primary-100 flex items-center justify-center text-primary-600">
            <i className="ri-mail-settings-line text-base"></i>
          </span>
          <h2 className="text-base font-semibold text-foreground-900">E-posta Bildirim İçerikleri</h2>
        </div>

        <div className="space-y-4">
          <div
            className="flex items-center justify-between p-4 rounded-lg border border-background-100 bg-background-50"
          >
            <div>
              <p className="text-sm font-medium text-foreground-900">Günlük Sipariş Özeti</p>
              <p className="text-xs text-foreground-500 mt-0.5">Günlük sipariş ve ciro özeti e-postası alın</p>
            </div>
            <button
              onClick={() => togglePref('appointmentReminders')}
              className={`relative w-11 h-6 rounded-full transition-colors cursor-pointer flex-shrink-0 ${
                prefs.appointmentReminders ? 'bg-primary-500' : 'bg-background-200'
              }`}
              aria-label={prefs.appointmentReminders ? 'Günlük sipariş özetini kapat' : 'Günlük sipariş özetini aç'}
            >
              <span
                className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-background-50 transition-transform ${
                  prefs.appointmentReminders ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
          <div
            className="flex items-center justify-between p-4 rounded-lg border border-background-100 bg-background-50"
          >
            <div>
              <p className="text-sm font-medium text-foreground-900">Fatura Ödeme Bildirimleri</p>
              <p className="text-xs text-foreground-500 mt-0.5">Bir fatura ödendiğinde bildirim alın</p>
            </div>
            <button
              onClick={() => togglePref('invoicePaidNotifications')}
              className={`relative w-11 h-6 rounded-full transition-colors cursor-pointer flex-shrink-0 ${
                prefs.invoicePaidNotifications ? 'bg-primary-500' : 'bg-background-200'
              }`}
              aria-label={prefs.invoicePaidNotifications ? 'Fatura bildirimleri kapat' : 'Fatura bildirimleri aç'}
            >
              <span
                className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-background-50 transition-transform ${
                  prefs.invoicePaidNotifications ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
          <div
            className="flex items-center justify-between p-4 rounded-lg border border-background-100 bg-background-50"
          >
            <div>
              <p className="text-sm font-medium text-foreground-900">Düşük Stok Uyarıları</p>
              <p className="text-xs text-foreground-500 mt-0.5">Stok 5 adedin altına düştüğünde uyarı alın</p>
            </div>
            <button
              onClick={() => togglePref('lowStockAlerts')}
              className={`relative w-11 h-6 rounded-full transition-colors cursor-pointer flex-shrink-0 ${
                prefs.lowStockAlerts ? 'bg-primary-500' : 'bg-background-200'
              }`}
              aria-label={prefs.lowStockAlerts ? 'Stok uyarıları kapat' : 'Stok uyarıları aç'}
            >
              <span
                className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-background-50 transition-transform ${
                  prefs.lowStockAlerts ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}