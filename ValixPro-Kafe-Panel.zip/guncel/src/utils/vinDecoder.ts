const NHTSA_BASE_URL = 'https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVinExtended';

export interface VinDetail {
  label: string;
  value: string;
}

export interface VinLookupResult {
  details: VinDetail[];
  make: string;
  model: string;
  year: string;
  color: string;
  notesText: string;
}

const VARIABLE_LABELS: Record<string, string> = {
  'make': 'Marka',
  'model': 'Model',
  'model year': 'Model Yılı',
  'manufacturer name': 'Üretici',
  'vehicle type': 'Araç Tipi',
  'body class': 'Gövde Tipi',
  'doors': 'Kapı Sayısı',
  'series': 'Seri',
  'trim': 'Trim / Donanım',
  'engine model': 'Motor Modeli',
  'engine manufacturer': 'Motor Üreticisi',
  'engine configuration': 'Motor Konfigürasyonu',
  'engine number of cylinders': 'Silindir Sayısı',
  'displacement (l)': 'Motor Hacmi (L)',
  'displacement (cc)': 'Motor Hacmi (CC)',
  'displacement (ci)': 'Motor Hacmi (CI)',
  'engine power (kw)': 'Motor Gücü (kW)',
  'engine horsepower': 'Motor Gücü (HP)',
  'engine brake (hp)': 'Motor Gücü (HP)',
  'valve train design': 'Supap Sistemi',
  'fuel injection type': 'Yakıt Enjeksiyonu',
  'fuel type - primary': 'Yakıt Tipi',
  'fuel type - secondary': 'İkincil Yakıt',
  'transmission style': 'Şanzıman Tipi',
  'transmission speeds': 'Vites Sayısı',
  'drive type': 'Çekiş Sistemi',
  'wheel base (inches)': 'Aks Mesafesi (inç)',
  'wheel base (mm)': 'Aks Mesafesi (mm)',
  'wheel base type': 'Aks Mesafesi Tipi',
  'track width (inches)': 'İz Genişliği (inç)',
  'exterior color': 'Dış Renk',
  'interior color': 'İç Renk',
  'plant city': 'Üretim Şehri',
  'plant state': 'Üretim Eyaleti',
  'plant country': 'Üretim Ülkesi',
  'plant company name': 'Fabrika',
  'gvwr': 'GVWR (lb)',
  'curb weight (lb)': 'Boş Ağırlık (lb)',
  'gross vehicle weight rating': 'Azami Yüklü Ağırlık',
  'brake system type': 'Fren Sistemi',
  'brake system description': 'Fren Detayı',
  'axles': 'Aks Sayısı',
  'axle configuration': 'Aks Konfigürasyonu',
  'aspiration': 'Aspirasyon',
  'cooling type': 'Soğutma Tipi',
  'emission standard': 'Emisyon Standardı',
  'engine stroke cycles': 'Motor Çevrimi',
  'entertainment system': 'Multimedya Sistemi',
  'other engine info': 'Ek Motor Bilgisi',
  'other restraint system info': 'Ek Güvenlik Bilgisi',
  'suspension type': 'Süspansiyon Tipi',
};

const SKIP_VARIABLES = new Set([
  'suggested vin', 'error code', 'error text', 'additional error text',
  'vehicle descriptor', 'possible values', 'destination market', 'note',
  'seat belt type',
  'front air bag locations', 'side air bag locations', 'knee air bag locations', 'curtain air bag locations',
  'air bag loc front', 'air bag loc side', 'air bag loc knee', 'air bag loc curtain',
  'abs', 'esc', 'electronic stability control', 'traction control', 'tpms', 'tire pressure monitoring system',
  'steering location', 'adaptive cruise control', 'blind spot monitor', 'forward collision warning',
  'lane departure warning', 'lane keep system', 'pedestrian automatic emergency braking',
  'rear cross traffic alert', 'crash imminenet braking', 'dynamic brake support',
  'automatic crash notification', 'event data recorder', 'edr',
  'keyless ignition', 'backup camera', 'parking assist', 'auto reverse system',
  'daytime running light', 'semiautomatic headlamp beam switching', 'adaptive driving beam',
  'lower beam headlamp light source', 'rear visibility system', 'base price',
  'bus floor config type', 'bus type',
  'custom motorcycle type', 'motorcycle suspension type', 'motorcycle chassis type',
  'trailer type', 'trailer body type', 'trailer length (ft)',
  'meets / exceeds fmvss', 'non land use',
]);

const SKIP_LABEL_PATTERNS = [
  /error/i, /suggested/i, /air\s*bag/i, /airbag/i, /seat\s*belt/i, /belt/i,
  /safety/i, /restraint/i, /crash/i, /collision/i, /braking.*auto/i,
  /camera/i, /headlamp/i, /headlight/i, /beam/i, /visibility/i, /night/i,
  /adaptive.*cruise/i, /cruise.*control/i, /blind.*spot/i, /lane/i,
  /parking.*assist/i, /park.*assist/i, /keyless/i, /ignition/i,
  /event.*data.*record/i, /edr/i, /backup/i, /reverse/i,
  /warning/i, /notification/i, /daytime/i, /lighting/i, /light source/i,
  /monitor/i, /sensor/i, /price/i, /msrp/i, /base/i, /fmvss/i,
  /non[- ]?land/i, /wheel.*size/i, /rim/i,
  /bus/i, /motorcycle/i, /trailer/i, /class/i,
];

function getLabel(variable: string): string {
  const lower = variable.toLowerCase().trim();
  if (VARIABLE_LABELS[lower]) return VARIABLE_LABELS[lower];
  return variable
    .split(/[\s-]+/)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(' ');
}

function shouldSkipVariable(variableName: string, label: string): boolean {
  const lowerVar = variableName.toLowerCase().trim();
  const lowerLabel = label.toLowerCase().trim();
  if (SKIP_VARIABLES.has(lowerVar)) return true;
  for (const pat of SKIP_LABEL_PATTERNS) {
    if (pat.test(lowerLabel)) return true;
  }
  if (lowerVar !== lowerLabel) {
    for (const pat of SKIP_LABEL_PATTERNS) {
      if (pat.test(lowerVar)) return true;
    }
  }
  return false;
}

export function decodeVinResult(responseData: { Results: { Variable: string; Value: string; ValueId: string }[] }): VinLookupResult | null {
  const results = responseData.Results || [];
  if (results.length === 0) return null;

  const rawMap = new Map<string, string>();
  for (const r of results) {
    const key = (r.Variable || '').toLowerCase().trim();
    const val = (r.Value || '').trim();
    if (val && val !== '' && !/^not\s+applicable$/i.test(val) && !/^see\s+note$/i.test(val)) {
      rawMap.set(key, val);
    }
  }

  if (rawMap.size === 0) return null;

  const tryFind = (...keys: string[]): string => {
    for (const k of keys) {
      const val = rawMap.get(k.toLowerCase().trim());
      if (val) return val;
    }
    return '';
  };

  const make = tryFind('make', 'manufacturer name');
  const model = tryFind('model', 'series', 'trim', 'body class');
  const year = tryFind('model year', 'year');
  const color = tryFind('exterior color', 'interior color', 'color');

  const details: VinDetail[] = [];

  const allPriorities = [
    'manufacturer name', 'model year', 'series', 'trim',
    'vehicle type', 'body class', 'doors',
    'exterior color', 'interior color',
    'engine model', 'engine manufacturer', 'engine configuration',
    'engine number of cylinders', 'displacement (l)', 'displacement (cc)', 'displacement (ci)',
    'engine power (kw)', 'engine horsepower', 'engine brake (hp)',
    'valve train design', 'fuel injection type', 'aspiration', 'cooling type',
    'engine stroke cycles', 'emission standard',
    'fuel type - primary', 'fuel type - secondary',
    'transmission style', 'transmission speeds',
    'drive type',
    'wheel base (inches)', 'wheel base (mm)', 'wheel base type',
    'track width (inches)',
    'curb weight (lb)', 'gross vehicle weight rating', 'gvwr',
    'axles', 'axle configuration',
    'brake system type', 'brake system description',
    'suspension type',
    'plant city', 'plant state', 'plant country', 'plant company name',
    'other engine info', 'other restraint system info', 'entertainment system',
  ];

  const seenVars = new Set<string>();

  for (const varName of allPriorities) {
    const key = varName.toLowerCase().trim();
    if (rawMap.has(key) && !seenVars.has(key)) {
      const label = getLabel(varName);
      if (!shouldSkipVariable(varName, label)) {
        seenVars.add(key);
        details.push({ label, value: rawMap.get(key)! });
      }
    }
  }

  for (const [key, val] of rawMap) {
    if (!seenVars.has(key)) {
      const originalVar = results.find(
        (r) => (r.Variable || '').toLowerCase().trim() === key
      );
      const varName = originalVar?.Variable || key;
      const label = getLabel(varName);
      if (!shouldSkipVariable(varName, label)) {
        seenVars.add(key);
        details.push({ label, value: val });
      }
    }
  }

  const notesLines: string[] = ['[VIN Sorgulama]'];
  for (const d of details) {
    notesLines.push(`${d.label}: ${d.value}`);
  }
  const notesText = notesLines.join('\n');

  return { details, make, model, year, color, notesText };
}

const VIN_PATTERN = /^[A-HJ-NPR-Z0-9]{17}$/;
const VIN_CACHE_TTL_MS = 24 * 60 * 60 * 1000;
const vinCache = new Map<string, { expiresAt: number; value: VinLookupResult | null }>();

export async function lookupVin(vin: string): Promise<VinLookupResult | null> {
  const normalizedVin = vin.trim().toUpperCase();
  if (!VIN_PATTERN.test(normalizedVin)) {
    throw new Error('VIN 17 karakter olmalı ve I, O, Q harflerini içermemelidir.');
  }
  const cached = vinCache.get(normalizedVin);
  if (cached && cached.expiresAt > Date.now()) return cached.value;
  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), 10_000);
  try {
    const response = await fetch(`${NHTSA_BASE_URL}/${encodeURIComponent(normalizedVin)}?format=json`, { signal: controller.signal, headers: { Accept: 'application/json' } });
    if (!response.ok) throw new Error('VIN sorgulama servisi şu anda kullanılamıyor.');
    const data = await response.json();
    const result = decodeVinResult(data);
    vinCache.set(normalizedVin, { expiresAt: Date.now() + VIN_CACHE_TTL_MS, value: result });
    return result;
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') throw new Error('VIN sorgusu zaman aşımına uğradı. Lütfen tekrar deneyin.');
    throw error;
  } finally {
    window.clearTimeout(timeoutId);
  }
}
