import * as XLSX from 'xlsx';

function downloadXlsx(workbook: XLSX.WorkBook, filename: string) {
  const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([wbout], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${filename}.xlsx`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ── Appointments ──
interface AppointmentExport {
  id: string;
  date: string;
  time: string;
  status: string;
  service_description: string;
  notes: string | null;
  customer_name: string;
  vehicle_info: string;
  plate_number: string;
  staff_name: string;
}

export function exportAppointmentsToExcel(appointments: AppointmentExport[], filename = 'Randevular') {
  const data = appointments.map((a) => ({
    'Tarih': a.date ? new Date(a.date).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }) : '',
    'Saat': a.time || '',
    'Müşteri': a.customer_name || '',
    'Araç': a.vehicle_info || '',
    'Plaka': a.plate_number || '',
    'Hizmet': a.service_description || '',
    'Personel': a.staff_name || '',
    'Durum': statusLabel(a.status),
    'Notlar': a.notes || '',
  }));

  const ws = XLSX.utils.json_to_sheet(data);
  setColumnWidths(ws, [{ wch: 20 }, { wch: 8 }, { wch: 25 }, { wch: 25 }, { wch: 12 }, { wch: 30 }, { wch: 20 }, { wch: 12 }, { wch: 30 }]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Randevular');
  downloadXlsx(wb, filename);
}

// ── Customers ──
interface CustomerExport {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  address: string | null;
  notes: string | null;
  created_at: string;
  vehicle_count: number;
  vehicles: string;
}

export function exportCustomersToExcel(customers: CustomerExport[], filename = 'Musteriler') {
  const data = customers.map((c) => ({
    'İsim': c.name,
    'E-posta': c.email || '',
    'Telefon': c.phone || '',
    'Adres': c.address || '',
    'Araç Sayısı': c.vehicle_count,
    'Araçlar': c.vehicles,
    'Notlar': c.notes || '',
    'Kayıt Tarihi': c.created_at ? new Date(c.created_at).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }) : '',
  }));

  const ws = XLSX.utils.json_to_sheet(data);
  setColumnWidths(ws, [{ wch: 25 }, { wch: 25 }, { wch: 15 }, { wch: 35 }, { wch: 12 }, { wch: 45 }, { wch: 30 }, { wch: 20 }]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Müşteriler');
  downloadXlsx(wb, filename);
}

// ── Vehicles ──
interface VehicleExport {
  id: string;
  make: string;
  model: string;
  year: number;
  plate_number: string;
  vin: string;
  color: string | null;
  customer_name: string;
  notes: string | null;
  created_at: string;
}

export function exportVehiclesToExcel(vehicles: VehicleExport[], filename = 'Araclar') {
  const data = vehicles.map((v) => ({
    'Marka': v.make,
    'Model': v.model,
    'Yıl': v.year,
    'Plaka': v.plate_number || '',
    'VIN': v.vin || '',
    'Renk': v.color || '',
    'Müşteri': v.customer_name || '',
    'Notlar': v.notes || '',
    'Kayıt Tarihi': v.created_at ? new Date(v.created_at).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }) : '',
  }));

  const ws = XLSX.utils.json_to_sheet(data);
  setColumnWidths(ws, [{ wch: 15 }, { wch: 20 }, { wch: 6 }, { wch: 12 }, { wch: 22 }, { wch: 12 }, { wch: 25 }, { wch: 30 }, { wch: 20 }]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Araçlar');
  downloadXlsx(wb, filename);
}

// ── Finans: Faturalar ──
interface InvoiceExport {
  id: string;
  invoice_number: string;
  amount: number;
  tax_amount: number;
  status: string;
  due_date: string | null;
  created_at: string;
  customer_name: string;
  customer_email: string;
  notes: string | null;
  item_count: number;
}

export function exportInvoicesToExcel(invoices: InvoiceExport[], filename = 'Faturalar') {
  const data = invoices.map((i) => ({
    'Fatura No': i.invoice_number,
    'Müşteri': i.customer_name || '',
    'E-posta': i.customer_email || '',
    'Tutar': Number(i.amount) + Number(i.tax_amount || 0),
    'Vergi': Number(i.tax_amount || 0),
    'Durum': statusLabel(i.status),
    'Son Ödeme': i.due_date ? new Date(i.due_date).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }) : '',
    'Tarih': i.created_at ? new Date(i.created_at).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }) : '',
    'Kalem Sayısı': i.item_count,
    'Notlar': i.notes || '',
  }));

  const ws = XLSX.utils.json_to_sheet(data);
  setColumnWidths(ws, [{ wch: 18 }, { wch: 25 }, { wch: 25 }, { wch: 14 }, { wch: 12 }, { wch: 12 }, { wch: 20 }, { wch: 20 }, { wch: 12 }, { wch: 30 }]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Faturalar');
  downloadXlsx(wb, filename);
}

// ── Finans: Gelir/Gider ──
interface TransactionExport {
  id: string;
  type: 'income' | 'expense';
  category: string;
  description: string;
  amount: number;
  transaction_date: string;
}

export function exportTransactionsToExcel(transactions: TransactionExport[], filename = 'GelirGider') {
  const data = transactions.map((t) => ({
    'Tarih': t.transaction_date ? new Date(t.transaction_date).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }) : '',
    'Tür': t.type === 'income' ? 'Gelir' : 'Gider',
    'Kategori': t.category || '',
    'Açıklama': t.description || '',
    'Tutar': Number(t.amount),
  }));

  const ws = XLSX.utils.json_to_sheet(data);
  setColumnWidths(ws, [{ wch: 20 }, { wch: 10 }, { wch: 20 }, { wch: 40 }, { wch: 14 }]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Gelir Gider');
  downloadXlsx(wb, filename);
}

// ── Finans: İkisi birden (2 sayfa) ──
export function exportFinanceToExcel(
  invoices: InvoiceExport[],
  transactions: TransactionExport[],
  filename = 'FinansRaporu',
) {
  const invData = invoices.map((i) => ({
    'Fatura No': i.invoice_number,
    'Müşteri': i.customer_name || '',
    'E-posta': i.customer_email || '',
    'Tutar': Number(i.amount) + Number(i.tax_amount || 0),
    'Vergi': Number(i.tax_amount || 0),
    'Durum': statusLabel(i.status),
    'Son Ödeme': i.due_date ? new Date(i.due_date).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }) : '',
    'Tarih': i.created_at ? new Date(i.created_at).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }) : '',
    'Kalem Sayısı': i.item_count,
    'Notlar': i.notes || '',
  }));

  const txData = transactions.map((t) => ({
    'Tarih': t.transaction_date ? new Date(t.transaction_date).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }) : '',
    'Tür': t.type === 'income' ? 'Gelir' : 'Gider',
    'Kategori': t.category || '',
    'Açıklama': t.description || '',
    'Tutar': Number(t.amount),
  }));

  const wsInvoices = XLSX.utils.json_to_sheet(invData);
  setColumnWidths(wsInvoices, [{ wch: 18 }, { wch: 25 }, { wch: 25 }, { wch: 14 }, { wch: 12 }, { wch: 12 }, { wch: 20 }, { wch: 20 }, { wch: 12 }, { wch: 30 }]);

  const wsTx = XLSX.utils.json_to_sheet(txData);
  setColumnWidths(wsTx, [{ wch: 20 }, { wch: 10 }, { wch: 20 }, { wch: 40 }, { wch: 14 }]);

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, wsInvoices, 'Faturalar');
  XLSX.utils.book_append_sheet(wb, wsTx, 'Gelir Gider');
  downloadXlsx(wb, filename);
}

// ── Inventory ──
interface InventoryExport {
  id: string;
  part_name: string;
  part_number: string;
  quantity: number;
  min_quantity: number;
  price: number;
  supplier: string;
  category: string;
}

export function exportInventoryToExcel(parts: InventoryExport[], filename = 'Envanter') {
  const data = parts.map((p) => ({
    'Parça Adı': p.part_name,
    'Parça No': p.part_number || '',
    'Kategori': p.category || '',
    'Miktar': p.quantity,
    'Min Miktar': p.min_quantity,
    'Birim Fiyat': Number(p.price),
    'Toplam Değer': Number(p.price) * p.quantity,
    'Tedarikçi': p.supplier || '',
    'Stok Durumu': p.quantity < p.min_quantity ? 'DÜŞÜK STOK' : 'Yeterli',
  }));

  const ws = XLSX.utils.json_to_sheet(data);
  setColumnWidths(ws, [{ wch: 25 }, { wch: 20 }, { wch: 15 }, { wch: 8 }, { wch: 10 }, { wch: 14 }, { wch: 14 }, { wch: 25 }, { wch: 12 }]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Envanter');
  downloadXlsx(wb, filename);
}

// ── Staff ──
interface StaffExport {
  id: string;
  name: string;
  email: string | null;
  role: string;
  phone: string | null;
  active: boolean;
  created_at: string;
}

const ROLE_LABELS: Record<string, string> = {
  admin: 'Yönetici',
  manager: 'Müdür',
  mechanic: 'Teknisyen',
  receptionist: 'Resepsiyonist',
};

export function exportStaffToExcel(staff: StaffExport[], filename = 'Personel') {
  const data = staff.map((s) => ({
    'İsim': s.name,
    'E-posta': s.email || '',
    'Telefon': s.phone || '',
    'Rol': ROLE_LABELS[s.role] || s.role,
    'Durum': s.active ? 'Aktif' : 'Pasif',
    'Katılım Tarihi': s.created_at ? new Date(s.created_at).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }) : '',
  }));

  const ws = XLSX.utils.json_to_sheet(data);
  setColumnWidths(ws, [{ wch: 25 }, { wch: 28 }, { wch: 16 }, { wch: 14 }, { wch: 8 }, { wch: 20 }]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Personel');
  downloadXlsx(wb, filename);
}

// ── Helpers ──
function statusLabel(status: string): string {
  switch (status) {
    case 'paid': return 'Ödendi';
    case 'pending': return 'Bekliyor';
    case 'overdue': return 'Gecikmiş';
    case 'draft': return 'Taslak';
    case 'scheduled': return 'Planlandı';
    case 'in-progress': return 'İşlemde';
    case 'completed': return 'Tamamlandı';
    case 'cancelled': return 'İptal';
    default: return status;
  }
}

function setColumnWidths(ws: XLSX.WorkSheet, widths: { wch: number }[]) {
  if (!ws['!cols']) ws['!cols'] = [];
  widths.forEach((w, i) => {
    ws['!cols']![i] = w;
  });
}