interface PaginationProps {
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalItems: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: number) => void;
}

const PAGE_SIZE_OPTIONS = [10, 25, 50];

export default function Pagination({
  currentPage,
  totalPages,
  pageSize,
  totalItems,
  onPageChange,
  onPageSizeChange,
}: PaginationProps) {
  if (totalItems === 0) return null;

  const startItem = (currentPage - 1) * pageSize + 1;
  const endItem = Math.min(currentPage * pageSize, totalItems);

  const getPageNumbers = (): (number | '...')[] => {
    const pages: (number | '...')[] = [];
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      pages.push(1);
      if (currentPage > 3) pages.push('...');
      const start = Math.max(2, currentPage - 1);
      const end = Math.min(totalPages - 1, currentPage + 1);
      for (let i = start; i <= end; i++) pages.push(i);
      if (currentPage < totalPages - 2) pages.push('...');
      pages.push(totalPages);
    }
    return pages;
  };

  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 px-5 py-3 border-t border-background-200/70">
      <div className="flex items-center gap-3">
        <span className="text-xs text-foreground-500 whitespace-nowrap">
          {startItem}–{endItem} / {totalItems}
        </span>
        <div className="flex items-center gap-1">
          <span className="text-xs text-foreground-400">Göster:</span>
          <select
            value={pageSize}
            onChange={(e) => onPageSizeChange(Number(e.target.value))}
            className="text-xs bg-background-100 border border-background-200/70 rounded-md px-2 py-1 text-foreground-700 cursor-pointer focus:outline-none focus:ring-1 focus:ring-primary-300"
          >
            {PAGE_SIZE_OPTIONS.map((size) => (
              <option key={size} value={size}>{size}</option>
            ))}
          </select>
        </div>
      </div>
      <div className="flex items-center gap-1">
        <button
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage <= 1}
          className="w-10 h-10 flex items-center justify-center rounded-md text-sm text-foreground-500 hover:bg-background-200 hover:text-foreground-700 transition-colors cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
        >
          <i className="ri-arrow-left-s-line text-base"></i>
        </button>
        {getPageNumbers().map((p, idx) =>
          p === '...' ? (
            <span key={`dots-${idx}`} className="w-10 h-10 flex items-center justify-center text-xs text-foreground-400">
              ...
            </span>
          ) : (
            <button
              key={p}
              onClick={() => onPageChange(p as number)}
              className={`w-10 h-10 flex items-center justify-center rounded-md text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                currentPage === p
                  ? 'bg-primary-500 text-background-50 dark:text-foreground-950'
                  : 'text-foreground-500 hover:bg-background-200 hover:text-foreground-700'
              }`}
            >
              {p}
            </button>
          ),
        )}
        <button
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage >= totalPages}
          className="w-10 h-10 flex items-center justify-center rounded-md text-sm text-foreground-500 hover:bg-background-200 hover:text-foreground-700 transition-colors cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
        >
          <i className="ri-arrow-right-s-line text-base"></i>
        </button>
      </div>
    </div>
  );
}