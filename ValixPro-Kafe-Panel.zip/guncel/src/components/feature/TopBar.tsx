import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDarkMode } from '@/hooks/useDarkMode';
import { supabase } from '@/lib/supabase';
import NotificationDropdown from '@/components/feature/NotificationDropdown';

interface StaffInfo {
  name: string;
  role: string;
  avatar_url?: string;
}

interface TopBarProps {
  onMenuClick: () => void;
}

const ROLE_MAP: Record<string, string> = {
  manager: 'Müdür',
  admin: 'Yönetici',
  administrator: 'Yönetici',
  barista: 'Barista',
  waiter: 'Garson',
  kitchen: 'Mutfak',
  cashier: 'Kasiyer',
  receptionist: 'Karşılama',
  reception: 'Karşılama',
};

export default function TopBar({ onMenuClick }: TopBarProps) {
  const navigate = useNavigate();
  const { isDark, toggle } = useDarkMode();
  const [staff, setStaff] = useState<StaffInfo>({ name: '', role: '' });
  const [shopAvatar, setShopAvatar] = useState<string | null>(null);
  const [showDropdown, setShowDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const stored = localStorage.getItem('autofix_staff');
    if (stored) {
      try {
        const s = JSON.parse(stored);
        setStaff({ name: s.name || '', role: s.role || '', avatar_url: s.avatar_url });
      } catch { /* ignore */ }
    }
  }, []);

  useEffect(() => {
    async function loadShopAvatar() {
      try {
        const { data, error } = await supabase
          .from('shop_settings')
          .select('avatar_url')
          .maybeSingle();
        if (!error && data?.avatar_url) {
          setShopAvatar(data.avatar_url);
        }
      } catch { /* ignore */ }
    }
    loadShopAvatar();
  }, []);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setShowDropdown(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    localStorage.removeItem('autofix_staff');
    navigate('/login');
  };

  const handleProfile = () => {
    setShowDropdown(false);
    navigate('/staff');
  };

  const handleSettings = () => {
    setShowDropdown(false);
    navigate('/settings');
  };

  const today = new Date();
  const formattedDate = today.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  }).replace('January','Ocak').replace('February','Şubat').replace('March','Mart').replace('April','Nisan').replace('May','Mayıs').replace('June','Haziran').replace('July','Temmuz').replace('August','Ağustos').replace('September','Eylül').replace('October','Ekim').replace('November','Kasım').replace('December','Aralık').replace('Monday','Pazartesi').replace('Tuesday','Salı').replace('Wednesday','Çarşamba').replace('Thursday','Perşembe').replace('Friday','Cuma').replace('Saturday','Cumartesi').replace('Sunday','Pazar');

  const avatarUrl = shopAvatar || staff.avatar_url ||
    'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=200&q=80';

  const displayRole = ROLE_MAP[staff.role?.toLowerCase()] || staff.role;

  return (
    <header className="h-16 bg-background-50/85 backdrop-blur-sm border-b border-background-200/70 flex items-center justify-between px-4 md:px-6 sticky top-0 z-30">
      <div className="flex items-center gap-3">
        <button
          onClick={onMenuClick}
          className="xl:hidden w-10 h-10 rounded-lg hover:bg-background-100 transition-colors flex items-center justify-center cursor-pointer text-foreground-500 hover:text-primary-500"
          title="Menü"
        >
          <i className="ri-menu-line text-lg"></i>
        </button>
        <p className="text-sm text-foreground-500 hidden sm:block">{formattedDate}</p>
      </div>

      <div className="flex items-center gap-3">
        <NotificationDropdown />

        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setShowDropdown(!showDropdown)}
            className="flex items-center gap-3 px-2 py-1.5 rounded-lg hover:bg-background-100 transition-colors cursor-pointer whitespace-nowrap"
          >
            <img
              src={avatarUrl}
              alt={staff.name}
              className="w-8 h-8 rounded-full object-cover"
            />
            <div className="text-left hidden sm:block">
              <p className="text-sm font-medium text-foreground-900 leading-tight">{staff.name}</p>
              <p className="text-xs text-foreground-500 leading-tight">{displayRole}</p>
            </div>
            <i className={`ri-arrow-down-s-line text-foreground-400 text-sm transition-transform ${showDropdown ? 'rotate-180' : ''}`}></i>
          </button>

          {showDropdown && (
            <div className="absolute right-0 top-full mt-2 w-52 bg-background-50 rounded-lg border border-background-200/70 py-1 shadow-sm z-50">
              <button
                onClick={handleProfile}
                className="w-full text-left px-4 py-2 text-sm text-foreground-700 hover:bg-background-100 transition-colors flex items-center gap-3 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-user-line text-base text-secondary-500"></i> Profil
              </button>
              <button
                onClick={handleSettings}
                className="w-full text-left px-4 py-2 text-sm text-foreground-700 hover:bg-background-100 transition-colors flex items-center gap-3 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-settings-3-line text-base text-secondary-500"></i> Ayarlar
              </button>
              <button
                onClick={() => { toggle(); setShowDropdown(false); }}
                className="w-full text-left px-4 py-2 text-sm text-foreground-700 hover:bg-background-100 transition-colors flex items-center gap-3 cursor-pointer whitespace-nowrap"
              >
                <i className={`${isDark ? 'ri-moon-clear-fill' : 'ri-sun-line'} text-base text-secondary-500`}></i>
                {isDark ? 'Koyu Mod' : 'Açık Mod'}
              </button>
              <hr className="my-1 border-background-200/70" />
              <button
                onClick={handleLogout}
                className="w-full text-left px-4 py-2 text-sm text-accent-600 hover:bg-accent-50 transition-colors flex items-center gap-3 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-logout-box-line text-base text-accent-500"></i> Çıkış Yap
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}