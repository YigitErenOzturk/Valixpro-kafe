import { useEffect, useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import Sidebar from '@/components/feature/Sidebar';
import TopBar from '@/components/feature/TopBar';
import { supabase } from '@/lib/supabase';
import { clearStoredStaff, getStoredStaff } from '@/lib/session';

const AUTH_TIMEOUT_MS = 5000;

export default function DashboardLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const [checked, setChecked] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [redirecting, setRedirecting] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function checkAuth() {
      try {
        const stored = getStoredStaff();
        if (!stored) {
          setRedirecting(true);
          navigate('/login');
          return;
        }

        const result = await Promise.race([
          supabase.auth.getSession(),
          new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error('AUTH_TIMEOUT')), AUTH_TIMEOUT_MS)
          ),
        ]);

        if (cancelled) return;

        if (!result.data.session) {
          clearStoredStaff();
          navigate('/login');
          return;
        }

        if (!cancelled) {
          setChecked(true);
        }
      } catch {
        clearStoredStaff();
        if (!cancelled) {
          navigate('/login');
        }
      }
    }

    checkAuth();

    return () => {
      cancelled = true;
    };
  }, [navigate]);

  // Readdy Agent widget — only visible when authenticated
  useEffect(() => {
    if (checked) {
      document.body.classList.add('vapi-widget-visible');
    }
    return () => {
      document.body.classList.remove('vapi-widget-visible');
    };
  }, [checked]);

  // Close sidebar on route change
  useEffect(() => {
    setSidebarOpen(false);
  }, [location.pathname]);

  // Don't show anything while redirecting to login — prevents spinner flash
  if (redirecting) {
    return null;
  }

  if (!checked) {
    return (
      <div className="min-h-screen relative overflow-hidden flex items-center justify-center">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1445116572660-236099ec97a0?auto=format&fit=crop&w=2000&q=80"
            alt=""
            className="w-full h-full object-cover blur-sm scale-105"
          />
          <div className="absolute inset-0 bg-black/70"></div>
        </div>
        <i className="ri-loader-4-line animate-spin text-2xl text-background-50 z-10"></i>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Cafe background — visible behind transparent panels */}
      <div className="fixed inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1445116572660-236099ec97a0?auto=format&fit=crop&w=2000&q=80"
          alt=""
          className="w-full h-full object-cover blur-sm scale-105"
        />
        <div className="absolute inset-0 bg-black/70"></div>
      </div>

      <div className="relative z-10 flex min-w-0">
        {/* Desktop sidebar — visible on xl screens and up */}
        <div className="hidden xl:block">
          <Sidebar isMobile={false} isOpen={false} onClose={() => setSidebarOpen(false)} />
        </div>

        {/* Mobile/Tablet sidebar overlay */}
        <div className="xl:hidden">
          <Sidebar isMobile={true} isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        </div>

        {/* Overlay for mobile/tablet sidebar */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-40 xl:hidden"
            onClick={() => setSidebarOpen(false)}
          ></div>
        )}

        <div className="flex-1 min-w-0 flex flex-col min-h-screen xl:ml-64">
          <TopBar onMenuClick={() => setSidebarOpen(!sidebarOpen)} />
          <main className="p-3 sm:p-4 md:p-6 flex-1 min-w-0 bg-background-50/95 backdrop-blur-sm overflow-x-hidden">
            <Outlet />
          </main>
        </div>
      </div>
    </div>
  );
}