import { NavLink, useLocation, Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

const navItems = [
  { path: '/', icon: 'ri-dashboard-line', label: 'Gösterge Paneli' },
  { path: '/orders', icon: 'ri-receipt-line', label: 'Siparişler' },
  { path: '/pos', icon: 'ri-shopping-bag-3-line', label: 'POS' },
  { path: '/kitchen', icon: 'ri-restaurant-2-line', label: 'Mutfak Ekranı' },
  { path: '/menu', icon: 'ri-qr-code-line', label: 'QR Menü' },
  { path: '/inventory', icon: 'ri-archive-stack-line', label: 'Stok Takibi' },
  { path: '/customers', icon: 'ri-user-star-line', label: 'Müşteriler' },
  { path: '/staff', icon: 'ri-team-line', label: 'Personel' },
  { path: '/reports', icon: 'ri-bar-chart-grouped-line', label: 'Raporlar' },
  { path: '/notifications', icon: 'ri-notification-3-line', label: 'Bildirimler' },
];

interface SidebarProps {
  isMobile: boolean;
  isOpen: boolean;
  onClose: () => void;
}

function SidebarContent() {
  const location = useLocation();

  return (
    <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
      {navItems.map((item) => {
        const isActive = item.path === '/'
          ? location.pathname === '/'
          : location.pathname.startsWith(item.path);
        return (
          <NavLink
            key={item.path}
            to={item.path}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors duration-150 whitespace-nowrap ${
              isActive
                ? 'bg-primary-500/15 text-primary-400'
                : 'text-background-400 hover:text-background-100 hover:bg-background-800/50'
            }`}
          >
            <span className="w-5 h-5 flex items-center justify-center text-base">
              <i className={item.icon}></i>
            </span>
            {item.label}
          </NavLink>
        );
      })}
    </nav>
  );
}

function SidebarFooter() {
  const location = useLocation();

  return (
    <div className="px-3 py-4 border-t border-background-800/60">
      <Link
        to="/settings"
        className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors duration-150 whitespace-nowrap ${
          location.pathname === '/settings'
            ? 'bg-primary-500/15 text-primary-400'
            : 'text-background-400 hover:text-background-100 hover:bg-background-800/50'
        }`}
      >
        <span className="w-5 h-5 flex items-center justify-center text-base">
          <i className="ri-settings-3-line"></i>
        </span>
        Ayarlar
      </Link>
    </div>
  );
}

export default function Sidebar({ isMobile, isOpen, onClose }: SidebarProps) {
  const [shopName, setShopName] = useState('ValixPro Cafe');
  const [shopLogo, setShopLogo] = useState<string | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem('autofix_staff');
    if (stored) {
      try {
        const s = JSON.parse(stored);
        if (s.shop_name) {
          setShopName(s.shop_name);
        }
      } catch { /* ignore */ }
    }
  }, []);

  useEffect(() => {
    async function loadShopLogo() {
      try {
        const { data, error } = await supabase
          .from('shop_settings')
          .select('avatar_url')
          .maybeSingle();
        if (!error && data?.avatar_url) {
          setShopLogo(data.avatar_url);
        }
      } catch { /* ignore */ }
    }
    loadShopLogo();
  }, []);

  const headerSection = (
    <div className="flex items-center gap-3 px-6 h-16 border-b border-background-800/60">
      {shopLogo ? (
        <img
          src={shopLogo}
          alt={shopName}
          className="w-9 h-9 rounded-lg object-cover flex-shrink-0"
        />
      ) : (
        <div className="w-9 h-9 rounded-lg bg-primary-500 flex items-center justify-center flex-shrink-0">
          <i className="ri-cup-fill text-background-50 text-lg"></i>
        </div>
      )}
      <div>
        <h1 className="text-background-50 font-heading text-base font-bold leading-tight">{shopName}</h1>
        <p className="text-background-600 text-xs leading-tight">Kafe Yönetim Paneli</p>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop sidebar */}
      {!isMobile && (
        <aside className="fixed left-0 top-0 h-full w-64 bg-background-950/85 backdrop-blur-sm flex flex-col z-40">
          {headerSection}
          <SidebarContent />
          <SidebarFooter />
        </aside>
      )}

      {/* Mobile overlay sidebar */}
      <aside
        className={`fixed left-0 top-0 h-full w-64 bg-background-950/95 backdrop-blur-sm flex flex-col z-50 transition-transform duration-300 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between px-6 h-16 border-b border-background-800/60">
          <div className="flex items-center gap-3">
            {shopLogo ? (
              <img
                src={shopLogo}
                alt={shopName}
                className="w-9 h-9 rounded-lg object-cover flex-shrink-0"
              />
            ) : (
              <div className="w-9 h-9 rounded-lg bg-primary-500 flex items-center justify-center flex-shrink-0">
                <i className="ri-cup-fill text-background-50 text-lg"></i>
              </div>
            )}
            <div>
              <h1 className="text-background-50 font-heading text-base font-bold leading-tight">{shopName}</h1>
              <p className="text-background-600 text-xs leading-tight">Kafe Yönetim Paneli</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-background-800/50 flex items-center justify-center cursor-pointer text-background-400 hover:text-background-100 transition-colors"
          >
            <i className="ri-close-line text-lg"></i>
          </button>
        </div>
        <SidebarContent />
        <SidebarFooter />
      </aside>
    </>
  );
}