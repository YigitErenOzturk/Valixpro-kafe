import { lazy, Suspense, type ReactNode } from 'react';
import type { RouteObject } from 'react-router-dom';
import DashboardLayout from '../components/feature/DashboardLayout';

const NotFound = lazy(() => import('../pages/NotFound'));
const Login = lazy(() => import('../pages/login/page'));
const Register = lazy(() => import('../pages/register/page'));
const Dashboard = lazy(() => import('../pages/dashboard/page'));
const Orders = lazy(() => import('../pages/orders/page'));
const Pos = lazy(() => import('../pages/pos/page'));
const Kitchen = lazy(() => import('../pages/kitchen/page'));
const Menu = lazy(() => import('../pages/menu/page'));
const Inventory = lazy(() => import('../pages/inventory/page'));
const Customers = lazy(() => import('../pages/customers/page'));
const Staff = lazy(() => import('../pages/staff/page'));
const Settings = lazy(() => import('../pages/settings/page'));
const Reports = lazy(() => import('../pages/reports/page'));
const Notifications = lazy(() => import('../pages/notifications/page'));

function load(element: ReactNode) {
  return (
    <Suspense fallback={<div className="min-h-[40vh] grid place-items-center" role="status" aria-live="polite"><span className="sr-only">Yükleniyor</span><i className="ri-loader-4-line animate-spin text-2xl" aria-hidden="true" /></div>}>
      {element}
    </Suspense>
  );
}

const routes: RouteObject[] = [
  { path: '/login', element: load(<Login />) },
  { path: '/register', element: load(<Register />) },
  {
    path: '/',
    element: <DashboardLayout />,
    children: [
      { index: true, element: load(<Dashboard />) },
      { path: 'orders', element: load(<Orders />) },
      { path: 'pos', element: load(<Pos />) },
      { path: 'kitchen', element: load(<Kitchen />) },
      { path: 'menu', element: load(<Menu />) },
      { path: 'inventory', element: load(<Inventory />) },
      { path: 'customers', element: load(<Customers />) },
      { path: 'staff', element: load(<Staff />) },
      { path: 'settings', element: load(<Settings />) },
      { path: 'notifications', element: load(<Notifications />) },
      { path: 'reports', element: load(<Reports />) },
    ],
  },
  { path: '*', element: load(<NotFound />) },
];

export default routes;
